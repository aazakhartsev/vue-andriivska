import { createStore } from 'vuex'

const ui = {
  namespaced: true,
  state: () => ({
    menuOpen: false,
  }),
  mutations: {
    TOGGLE_MENU(state) {
      state.menuOpen = !state.menuOpen
    },
    CLOSE_MENU(state) {
      state.menuOpen = false
    },
  },
  actions: {
    toggleMenu({ commit }) {
      commit('TOGGLE_MENU')
    },
    closeMenu({ commit }) {
      commit('CLOSE_MENU')
    },
  },
  getters: {
    isMenuOpen: (state) => state.menuOpen,
  },
}

const partner = {
  namespaced: true,
  state: () => ({
    formName: '',
    formPhone: '',
    submitted: false,
    loading: false,
  }),
  mutations: {
    SET_FORM_NAME(state, value) {
      state.formName = value
    },
    SET_FORM_PHONE(state, value) {
      state.formPhone = value
    },
    SET_SUBMITTED(state, value) {
      state.submitted = value
    },
    SET_LOADING(state, value) {
      state.loading = value
    },
  },
  actions: {
    submitForm({ commit, state }) {
      if (!state.formName || !state.formPhone) return
      commit('SET_LOADING', true)
      setTimeout(() => {
        commit('SET_SUBMITTED', true)
        commit('SET_LOADING', false)
        commit('SET_FORM_NAME', '')
        commit('SET_FORM_PHONE', '')
      }, 800)
    },
  },
}

export default createStore({
  modules: {
    ui,
    partner,
  },
})
