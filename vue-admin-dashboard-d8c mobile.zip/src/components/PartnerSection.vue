<template>
  <section class="partner" id="partners">
    <div class="partner__inner">
      <h2 class="partner__title">
        <span class="text-accent">Партнерська</span>
        <span class="text-white"> мережа</span>
      </h2>

      <div class="partner__layout">
        <div class="partner__shelf">
          <div class="partner__shelf-glow"></div>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/43b6384e7bb9c6cf80fa4a79ff1f8094c37c6b14?width=90"
            alt=""
            aria-hidden="true"
            class="partner__bubble partner__bubble--1"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/2f92b65b421f588374999978f8fadf2a48e6829b?width=90"
            alt=""
            aria-hidden="true"
            class="partner__bubble partner__bubble--2"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/2a24cf5f8f670a84dc4979ee1b14b0ee7c0a7e7f?width=518"
            alt="Стійка з бутлями"
            class="partner__shelf-img"
          />
        </div>

        <div class="partner__content">
          <div class="partner__flow">
            <p class="partner__question">Маєте бізнес-центр, ОСББ чи будинок з охороною?</p>
            <div class="partner__arrow">
              <svg width="1" height="60" viewBox="0 0 1 60" fill="none">
                <path d="M0.5 0 L0.5 60" stroke="#FF7A2A" stroke-width="2"/>
                <path d="M0.5 60 L-6 48 M0.5 60 L7 48" stroke="#FF7A2A" stroke-width="2" stroke-linecap="round"/>
              </svg>
            </div>
            <p class="partner__action">Встановлюйте наші стійки з бутлями</p>
            <div class="partner__arrow">
              <svg width="1" height="60" viewBox="0 0 1 60" fill="none">
                <path d="M0.5 0 L0.5 60" stroke="#FF7A2A" stroke-width="2"/>
                <path d="M0.5 60 L-6 48 M0.5 60 L7 48" stroke="#FF7A2A" stroke-width="2" stroke-linecap="round"/>
              </svg>
            </div>
            <p class="partner__reward">
              отримуйте
              <span class="partner__percent">10%</span><br>
              від продажів
            </p>
          </div>
        </div>
      </div>

      <div class="partner__form-wrap">
        <div v-if="!submitted" class="partner__form">
          <div class="partner-form__field">
            <input
              v-model="formName"
              type="text"
              placeholder="Імʼя *"
              class="partner-form__input"
            />
          </div>
          <div class="partner-form__field">
            <input
              v-model="formPhone"
              type="tel"
              placeholder="+380 (__) ___ __ __"
              class="partner-form__input"
            />
          </div>
          <button
            class="partner-form__btn"
            :disabled="loading"
            @click="submitForm"
          >
            {{ loading ? 'Надсилаємо...' : 'Стати партнером' }}
          </button>
        </div>

        <div v-else class="partner__success">
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
            <circle cx="24" cy="24" r="22" stroke="#FF7A2A" stroke-width="2"/>
            <path d="M14 24 L21 31 L34 17" stroke="#FF7A2A" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <p>Дякуємо! Ми зв'яжемося з вами найближчим часом.</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'PartnerSection',
  computed: {
    formName: {
      get() {
        return this.$store.state.partner.formName
      },
      set(value) {
        this.$store.commit('partner/SET_FORM_NAME', value)
      },
    },
    formPhone: {
      get() {
        return this.$store.state.partner.formPhone
      },
      set(value) {
        this.$store.commit('partner/SET_FORM_PHONE', value)
      },
    },
    submitted() {
      return this.$store.state.partner.submitted
    },
    loading() {
      return this.$store.state.partner.loading
    },
  },
  methods: {
    submitForm() {
      this.$store.dispatch('partner/submitForm')
    },
  },
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.partner {
  padding: 60px 0;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 32px;
    font-weight: 400;
    line-height: 104%;
    letter-spacing: -0.05em;
    text-align: center;
    margin-bottom: 40px;

    @media (min-width: 768px) {
      font-size: 40px;
    }
  }

  &__layout {
    display: flex;
    flex-direction: column;
    gap: 40px;
    align-items: center;
    margin-bottom: 48px;

    @media (min-width: 768px) {
      flex-direction: row;
      align-items: flex-start;
      gap: 60px;
    }
  }

  &__shelf {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 360px;
    flex-shrink: 0;

    @media (min-width: 768px) {
      width: 280px;
    }
  }

  &__shelf-glow {
    position: absolute;
    width: 300px;
    height: 300px;
    border-radius: 50%;
    background: #FF7A2A;
    filter: blur(66px);
    opacity: 0.5;
  }

  &__shelf-img {
    position: relative;
    z-index: 2;
    width: 240px;
    height: auto;
    object-fit: contain;
  }

  &__bubble {
    position: absolute;
    z-index: 3;

    &--1 {
      width: 40px;
      bottom: 30%;
      right: 10%;
      transform: rotate(-178deg);
    }

    &--2 {
      width: 40px;
      top: 20%;
      left: 10%;
      transform: rotate(-11deg);
    }
  }

  &__content {
    flex: 1;
    display: flex;
    justify-content: center;
  }

  &__flow {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    gap: 0;
  }

  &__question,
  &__action {
    font-family: 'Rubik', sans-serif;
    font-size: 26px;
    font-weight: 400;
    color: #fff;
    line-height: 104%;
    letter-spacing: -0.05em;
    max-width: 280px;
  }

  &__arrow {
    display: flex;
    justify-content: center;
    margin: 8px 0;
  }

  &__reward {
    font-family: 'Rubik', sans-serif;
    font-size: 26px;
    font-weight: 400;
    color: #fff;
    line-height: 80%;
    letter-spacing: -0.05em;
    text-align: center;
  }

  &__percent {
    font-family: 'Rubik', sans-serif;
    font-size: 72px;
    font-weight: 400;
    color: #FF7A2A;
    line-height: 80%;
    display: block;
    margin: 4px 0;
  }

  &__form-wrap {
    max-width: 360px;
    margin: 0 auto;
  }

  &__form {
    background: rgba(217, 217, 217, 0.20);
    border-radius: 16px;
    padding: 28px;
    display: flex;
    flex-direction: column;
    gap: 14px;
  }

  &__success {
    background: rgba(217, 217, 217, 0.20);
    border-radius: 16px;
    padding: 40px 28px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 16px;
    text-align: center;
    font-family: 'Rubik', sans-serif;
    font-size: 16px;
    color: #fff;
  }
}

.partner-form {
  &__field {
    width: 100%;
  }

  &__input {
    width: 100%;
    height: 47px;
    border-radius: 6px;
    border: none;
    background: #fff;
    padding: 0 20px;
    font-family: 'Rubik', sans-serif;
    font-size: 16px;
    color: #000;
    letter-spacing: -0.05em;
    outline: none;

    &::placeholder {
      color: rgba(0,0,0,0.5);
    }

    &:focus {
      box-shadow: 0 0 0 2px rgba(255,122,42,0.4);
    }
  }

  &__btn {
    width: 100%;
    height: 47px;
    border-radius: 16px;
    border: none;
    background: #FF7A2A;
    color: #000;
    font-family: 'Rubik', sans-serif;
    font-size: 17px;
    font-weight: 400;
    letter-spacing: -0.05em;
    cursor: pointer;
    transition: opacity 0.2s;

    &:hover {
      opacity: 0.9;
    }

    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  }
}
</style>
