<template>
  <section class="quality">
    <div class="quality__inner">
      <h2 class="quality__title">
        <span class="text-white">Захист </span>
        <span class="text-accent">якості</span>
      </h2>

      <div class="quality__layout">
        <div class="quality__shield">
          <div class="quality__shield-glow"></div>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/a8281187ad3b10d6a4d7b322221203ef471257a2?width=103"
            alt=""
            aria-hidden="true"
            class="quality__bubble quality__bubble--1"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/53468e1d99f5078e5a428e8a63ec1dbfec2df0a2?width=72"
            alt=""
            aria-hidden="true"
            class="quality__bubble quality__bubble--2"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/ab21f064639b30ef78fb6021b025f22d17d5aeba?width=72"
            alt=""
            aria-hidden="true"
            class="quality__bubble quality__bubble--3"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/a8b7d131f2cd44dd5c78b5cefadedbf6590df01e?width=606"
            alt="Захист якості води"
            class="quality__shield-img"
          />
        </div>

        <div class="quality__points">
          <div v-for="(point, index) in points" :key="index" class="quality-point">
            <div class="quality-point__bullet"></div>
            <div class="quality-point__content">
              <span class="quality-point__title">{{ point.title }}</span>
              <span class="quality-point__desc">{{ point.desc }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'QualityProtectionSection',
  data() {
    return {
      points: [
        {
          title: 'Полікарбонатний бутель',
          desc: 'Полікарбонат добре зберігає чистоту і не взаємодіє з водою — хімічно нейтральний матеріал, схвалений для харчового використання.',
        },
        {
          title: 'Поліетиленовий захисний пакет',
          desc: 'Кожен бутель загорнутий у пакет, що захищає від зовнішніх забруднень та сонячних променів під час зберігання та доставки.',
        },
        {
          title: 'Миття чистою водою + пара 60°C',
          desc: 'Перед кожним наповненням бутель ретельно промивається та обробляється гарячою парою — надійна гігієнічна підготовка без хімії.',
        },
        {
          title: 'Герметичне пломбування',
          desc: 'Після наповнення бутель пломбується, що гарантує незайманість води до моменту відкриття у вас вдома.',
        },
      ],
    }
  },
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.quality {
  padding: 60px 0;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 32px;
    font-weight: 400;
    line-height: 104%;
    letter-spacing: -0.05em;
    text-align: center;
    margin-bottom: 32px;

    @media (min-width: 768px) {
      font-size: 40px;
    }
  }

  &__layout {
    display: flex;
    flex-direction: column;
    gap: 32px;

    @media (min-width: 768px) {
      flex-direction: row;
      align-items: center;
      gap: 48px;
    }
  }

  &__shield {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 320px;
    flex-shrink: 0;

    @media (min-width: 768px) {
      width: 340px;
    }
  }

  &__shield-glow {
    position: absolute;
    width: 300px;
    height: 300px;
    border-radius: 50%;
    background: #FF7A2A;
    filter: blur(57px);
    opacity: 0.6;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  &__shield-img {
    position: relative;
    z-index: 2;
    width: 280px;
    height: auto;
    object-fit: contain;
  }

  &__bubble {
    position: absolute;
    z-index: 3;

    &--1 {
      width: 45px;
      bottom: 30px;
      left: 30%;
    }

    &--2 {
      width: 32px;
      top: 10px;
      right: 20%;
    }

    &--3 {
      width: 32px;
      top: 40%;
      left: 10%;
    }
  }

  &__points {
    display: flex;
    flex-direction: column;
    gap: 20px;
    flex: 1;
  }
}

.quality-point {
  display: flex;
  gap: 14px;
  align-items: flex-start;

  &__bullet {
    width: 8px;
    height: 8px;
    border-radius: 2px;
    background: #fff;
    flex-shrink: 0;
    margin-top: 6px;
  }

  &__content {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 18px;
    font-weight: 400;
    color: #FF7A2A;
    letter-spacing: -0.05em;
    line-height: 100%;
  }

  &__desc {
    font-family: 'Rubik', sans-serif;
    font-size: 13px;
    font-weight: 400;
    color: #fff;
    letter-spacing: -0.05em;
    line-height: 1.4;
  }
}
</style>
