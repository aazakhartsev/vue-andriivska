<template>
  <section class="hero">
    <div class="hero__bg" aria-hidden="true">
      <img
        class="hero__bg-img hero__bg-img--1"
        src="https://api.builder.io/api/v1/image/assets/TEMP/f26134f86f878b53b312eaa39ed557e28b321c56?width=2236"
        alt=""
      />
      <img
        class="hero__bg-img hero__bg-img--2"
        src="https://api.builder.io/api/v1/image/assets/TEMP/a725065ef082c4370ccac1eb21f863a5880c2cee?width=1912"
        alt=""
      />
    </div>

    <div class="hero__body">
      <!-- Left column: badges -->
      <div class="hero__left">
        <div class="badge">
          <div class="badge__icon">
            <svg width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path d="M20.0174 8.13563C21.3895 9.49821 22.326 11.2376 22.7082 13.1331C23.0904 15.0287 22.901 16.9951 22.1641 18.7829C21.4272 20.5707 20.176 22.0994 18.5691 23.1751C16.9622 24.2508 15.0721 24.825 13.1384 24.825C11.2047 24.825 9.31453 24.2508 7.70764 23.1751C6.10075 22.0994 4.84952 20.5707 4.11263 18.7829C3.37573 16.9951 3.18637 15.0287 3.56856 13.1331C3.95074 11.2376 4.88726 9.49821 6.25933 8.13563L13.1381 1.48132L20.0174 8.13563Z" stroke="white" stroke-width="1.03406" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M16.3366 11.9901C16.9744 12.6237 17.4098 13.4324 17.5875 14.3137C17.7651 15.1951 17.677 16.1093 17.3344 16.9406C16.9917 17.7718 16.4099 18.4825 15.6628 18.9826C14.9157 19.4828 14.0369 19.7498 13.1378 19.7498C12.2387 19.7498 11.3599 19.4828 10.6128 18.9826C9.86565 18.4825 9.28387 17.7718 8.94122 16.9406C8.59857 16.1093 8.51048 15.1951 8.68812 14.3137C8.86576 13.4324 9.30113 12.6237 9.93901 11.9901L13.1381 8.89575L16.3366 11.9901Z" stroke="white" stroke-width="1.03406" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="badge__text">
            <span class="badge__title">Ультрачиста вода</span>
            <span class="badge__desc">збагачена всіма необхідними мінералами</span>
          </div>
        </div>

        <div class="badge">
          <div class="badge__icon">
            <svg width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path d="M14.5522 6.42111L8.63086 14.9573L12.7845 14.8322L12.2485 20.3801L18.1698 11.8439L14.0162 11.969L14.5522 6.42111Z" stroke="white" stroke-width="1.03786" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M13.4022 25.4053C20.0322 25.4053 25.4069 20.0306 25.4069 13.4006C25.4069 6.77058 20.0322 1.39589 13.4022 1.39589C6.77215 1.39589 1.39746 6.77058 1.39746 13.4006C1.39746 20.0306 6.77215 25.4053 13.4022 25.4053Z" stroke="white" stroke-width="1.03786" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="badge__text">
            <span class="badge__title">Іноваційна логістика</span>
            <span class="badge__desc">доставка виключно електротранспортом</span>
          </div>
        </div>

        <div class="badge">
          <div class="badge__icon">
            <svg width="31" height="31" viewBox="0 0 31 31" fill="none">
              <path d="M15.2473 21.2415C18.559 21.2415 21.2437 18.5568 21.2437 15.2451C21.2437 11.9334 18.559 9.24875 15.2473 9.24875C11.9356 9.24875 9.25098 11.9334 9.25098 15.2451C9.25098 18.5568 11.9356 21.2415 15.2473 21.2415Z" stroke="white" stroke-width="1.03786" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M1.58789 15.2451H6.25512M15.2459 28.9081V24.2384M15.2459 6.25815V1.58838M24.2404 15.2451H28.9076M5.5842 24.9004L8.88481 21.6004M24.905 24.9055L21.6025 21.603M8.88735 8.88911L5.5842 5.58723M21.6025 8.88466L24.9024 5.58469" stroke="white" stroke-width="1.03786" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="badge__text">
            <span class="badge__title">Енергія сонця</span>
            <span class="badge__desc">100% забезпечення себе електроенергією</span>
          </div>
        </div>
      </div>

      <!-- Bottom: title and CTA -->
      <div class="hero__bottom">
        <h1 class="hero__title">
          <span class="text-accent">Природна</span>
          <span class="text-white"> вода</span><br>
          <span class="text-accent">з</span>
          <span class="text-white"> </span>
          <span class="text-accent">Сеноманського</span>
          <span class="text-white"> водоносного горизонту</span>
        </h1>

        <div class="hero__cta">
          <a href="tel:+380634908000" class="hero__btn hero__btn--order">Замовити</a>
          <a href="tel:+380634908000" class="hero__btn hero__btn--phone">+38 (063) 490 8000</a>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'HeroSection',
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.hero {
  position: relative;
  min-height: 860px;
  overflow: hidden;
  background: #0863C7;
  padding-top: 100px;

  &__bg {
    position: absolute;
    inset: 0;
    z-index: 0;

    &-img {
      position: absolute;
      top: 0;
      height: 100%;
      object-fit: cover;

      &--1 {
        left: -30%;
        width: 170%;
        opacity: 0.75;
      }

      &--2 {
        right: -8%;
        width: 115%;
        opacity: 0.6;
      }
    }
  }

  &__body {
    position: relative;
    z-index: 2;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px 60px;
    display: flex;
    flex-direction: column;
    min-height: 760px;
    justify-content: space-between;

    @media (min-width: 1200px) {
      flex-direction: row;
      align-items: flex-end;
      gap: 60px;
    }
  }

  &__left {
    display: flex;
    flex-direction: column;
    gap: 16px;
    margin-top: 8px;

    @media (min-width: 1200px) {
      margin-bottom: 60px;
    }
  }

  &__bottom {
    margin-top: auto;

    @media (min-width: 1200px) {
      flex: 1;
    }
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 34px;
    font-weight: 400;
    line-height: 90%;
    letter-spacing: -0.05em;
    margin-bottom: 36px;

    @media (min-width: 768px) {
      font-size: 48px;
      max-width: 520px;
    }

    @media (min-width: 1200px) {
      font-size: 56px;
      max-width: 600px;
    }
  }

  &__cta {
    display: flex;
    flex-direction: column;
    gap: 12px;
    max-width: 260px;

    @media (min-width: 768px) {
      flex-direction: row;
      max-width: none;
    }
  }

  &__btn {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 48px;
    border-radius: 16px;
    font-family: 'Rubik', sans-serif;
    font-size: 16px;
    font-weight: 400;
    letter-spacing: -0.05em;
    text-decoration: none;
    cursor: pointer;
    transition: opacity 0.2s;
    padding: 0 24px;

    &:hover {
      opacity: 0.9;
    }

    &--order {
      background: #FF7A2A;
      color: #000;
      min-width: 160px;
    }

    &--phone {
      background: rgba(255, 255, 255, 0.10);
      color: #fff;
    }
  }
}

.badge {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 6px;
  width: 144px;
  padding: 10px 12px;
  border-radius: 20px;
  background: rgba(0, 0, 0, 0.00);

  &__icon {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  &__text {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 15px;
    font-weight: 400;
    color: #FF7A2A;
    letter-spacing: -0.07em;
    line-height: 90%;
  }

  &__desc {
    font-family: 'Rubik', sans-serif;
    font-size: 12px;
    font-weight: 400;
    color: #fff;
    letter-spacing: -0.07em;
    line-height: 90%;
  }
}
</style>
