<template>
  <section class="water-journey">
    <div class="water-journey__inner">
      <div class="water-journey__image">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/ed7beecd486a581ea9d9f9baa98a0f26ee004a8e?width=972"
          alt="Шлях крізь землю"
        />
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'WaterJourneySection',
}
</script>

<style scoped lang="scss">
.water-journey {
  overflow: hidden;
  position: relative;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 0 40px;
  }

  &__image {
    display: flex;
    justify-content: center;
    overflow: hidden;

    img {
      width: 100%;
      max-width: 700px;
      height: auto;
      object-fit: cover;
    }
  }
}
</style>
