<template>
  <section class="docs">
    <div class="docs__inner">
      <h2 class="docs__title">
        <span class="text-white">Цифровий </span>
        <span class="text-accent">комфорт:</span>
        <span class="text-accent"> Заощаджуйте час</span>
        <span class="text-white"> на папері</span>
      </h2>
      <p class="docs__subtitle">
        Ми використовуємо тільки електронний документообіг.<br>
        Більше ніяких паперів та очікування кур'єра.
      </p>

      <div class="docs__visual">
        <div class="docs__glow"></div>
        <div class="docs__bubbles">
          <img src="https://api.builder.io/api/v1/image/assets/TEMP/f5ac7591029176a8e5e20818f22641e4c0b5f701?width=63" alt="" aria-hidden="true" class="docs__bubble docs__bubble--1"/>
          <img src="https://api.builder.io/api/v1/image/assets/TEMP/71b2d17f26b1f65a035887fbd8c59d5e451dfb9d?width=44" alt="" aria-hidden="true" class="docs__bubble docs__bubble--2"/>
          <img src="https://api.builder.io/api/v1/image/assets/TEMP/ea062328ad034287168aad7dee43a366ca8d5774?width=63" alt="" aria-hidden="true" class="docs__bubble docs__bubble--3"/>
        </div>
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/d0fbc7ed680d9a980fb49de8d0baba5bf4d18c0c?width=712"
          alt="Система документообігу"
          class="docs__doc-img"
        />
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/b08ee8a75d054114ccdd4bbb93c765939835a892?width=195"
          alt="Месенджери"
          class="docs__messengers-img"
        />
      </div>

      <div class="docs__steps">
        <div v-for="(step, index) in steps" :key="index" class="doc-step">
          <div class="doc-step__number">{{ index + 1 }}</div>
          <p class="doc-step__text">{{ step }}</p>
          <svg v-if="index < steps.length - 1" class="doc-step__arrow" width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M10 0 L10 20 M5 15 L10 20 L15 15" stroke="rgba(255,122,42,0.8)" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'DocumentSection',
  data() {
    return {
      steps: [
        'Формування документу',
        'Відправка у Вчасно, M.E.Doc, WhatsApp, Telegram, Viber, e-mail',
        'Підписання документу за допомогою ЕЦП',
      ],
    }
  },
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.docs {
  padding: 60px 0;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
    text-align: center;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 32px;
    font-weight: 400;
    line-height: 90%;
    letter-spacing: -0.05em;
    margin-bottom: 16px;

    @media (min-width: 768px) {
      font-size: 40px;
    }
  }

  &__subtitle {
    font-family: 'Rubik', sans-serif;
    font-size: 14px;
    font-weight: 400;
    color: #fff;
    letter-spacing: -0.07em;
    opacity: 0.9;
    margin-bottom: 40px;
    line-height: 1.5;
  }

  &__visual {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 200px;
    margin-bottom: 40px;
  }

  &__glow {
    position: absolute;
    width: 90%;
    height: 150px;
    background: #FF7A2A;
    border-radius: 50%;
    filter: blur(44px);
    opacity: 0.45;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  &__bubbles {
    position: absolute;
    inset: 0;
    pointer-events: none;
  }

  &__bubble {
    position: absolute;

    &--1 {
      width: 28px;
      top: 0;
      left: 55%;
    }

    &--2 {
      width: 20px;
      bottom: 15%;
      right: 5%;
    }

    &--3 {
      width: 28px;
      top: 15%;
      left: 2%;
      transform: rotate(-17deg);
    }
  }

  &__doc-img {
    position: relative;
    z-index: 2;
    width: 100%;
    max-width: 400px;
    height: auto;
    object-fit: contain;
  }

  &__messengers-img {
    position: absolute;
    z-index: 3;
    width: 90px;
    height: auto;
    top: 50%;
    left: 50%;
    transform: translate(-15%, -50%);
  }

  &__steps {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;

    @media (min-width: 768px) {
      flex-direction: row;
      justify-content: center;
      align-items: flex-start;
      gap: 0;
    }
  }
}

.doc-step {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  max-width: 160px;

  @media (min-width: 768px) {
    flex-direction: row;
    align-items: flex-start;
    max-width: none;
    flex: 1;

    &:last-child .doc-step__arrow {
      display: none;
    }
  }

  &__number {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: #FF7A2A;
    color: #000;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Rubik', sans-serif;
    font-size: 14px;
    font-weight: 500;
    flex-shrink: 0;
  }

  &__text {
    font-family: 'Rubik', sans-serif;
    font-size: 13px;
    font-weight: 400;
    color: #fff;
    letter-spacing: -0.07em;
    line-height: 1.3;
    text-align: center;

    @media (min-width: 768px) {
      text-align: left;
      max-width: 140px;
    }
  }

  &__arrow {
    flex-shrink: 0;
    align-self: flex-start;
    margin-top: 4px;

    @media (min-width: 768px) {
      transform: rotate(-90deg);
      margin-top: 4px;
      margin-left: 8px;
    }
  }
}
</style>
