<template>
  <section class="prices" id="prices">
    <div class="prices__inner">
      <h2 class="prices__title">
        <span class="text-white">Це дозволяє нам </span>
        <span class="text-accent">тримати</span>
        <span class="text-white"> найкращу </span>
        <span class="text-accent">ціну</span>
        <span class="text-white"> в Україні</span>
      </h2>

      <div class="prices__cards">
        <div class="price-card price-card--featured">
          <div class="price-card__top-badge">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/fbd01529d93d471bfbbc20efa52f6c19ce926fbe?width=228"
              alt="ТОП продажів"
              class="price-card__top-badge-img"
            />
            <span class="price-card__top-badge-text">ТОП<br><small>продажів</small></span>
          </div>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/8f7bd8655ba10d7a96eb2e55c4c28b243f5063db?width=194"
            alt="Бутиль 19л"
            class="price-card__bottle"
          />
          <p class="price-card__desc">Якщо Ви підключені до нашої мережі, або у Вашому будинку стоїть наша стійка</p>
          <div class="price-card__price"><span class="price-card__price-amount">100</span> грн</div>
        </div>

        <div class="price-card">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/81a7a3bb25855acef72a29717f5b3ba67c27b293?width=196"
            alt="Бутиль 19л"
            class="price-card__bottle"
          />
          <p class="price-card__desc">Якщо Ви не підключені до нашої мережі</p>
          <div class="price-card__price">від <span class="price-card__price-amount">150</span> грн</div>
        </div>

        <div class="price-card">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/9ca8a91206884778cf4714bbe730738e713fe544?width=204"
            alt="Private label бутиль"
            class="price-card__bottle"
          />
          <p class="price-card__desc">Private lable та доставка у чітко визначений час</p>
          <div class="price-card__price"><span class="price-card__price-amount">250</span> грн</div>
        </div>
      </div>

      <p class="prices__note">
        Вартість води вказана з урахуванням доставки до квартири чи офісу без вартості бутля, який станом на 04.04.2026 складає 350 грн.
        Вартість бутля не сплачується, якщо клієнт надає свій бутиль.
        Заставна вартість повертається клієнту за першою вимогою при поверненні бутля.
      </p>

      <div class="prices__cta">
        <a href="tel:+380634908000" class="btn-order">Замовити</a>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'PriceSection',
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.prices {
  padding: 60px 0;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 32px;
    font-weight: 400;
    line-height: 90%;
    letter-spacing: -0.05em;
    text-align: center;
    margin-bottom: 40px;

    @media (min-width: 768px) {
      font-size: 40px;
    }
  }

  &__cards {
    display: flex;
    flex-direction: column;
    gap: 20px;
    align-items: center;

    @media (min-width: 768px) {
      flex-direction: row;
      justify-content: center;
      align-items: stretch;
      gap: 20px;
    }
  }

  &__note {
    font-family: 'Rubik', sans-serif;
    font-size: 13px;
    font-weight: 400;
    color: #fff;
    letter-spacing: -0.05em;
    line-height: 1.5;
    margin-top: 32px;
    opacity: 0.85;
  }

  &__cta {
    display: flex;
    justify-content: center;
    margin-top: 28px;
  }
}

.price-card {
  background: rgba(217, 217, 217, 0.20);
  border-radius: 46px;
  padding: 20px 24px 28px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  width: 100%;
  max-width: 260px;
  position: relative;

  &--featured {
    .price-card__top-badge {
      position: absolute;
      top: 0;
      right: 0;
      width: 110px;
      height: 110px;
    }
  }

  &__top-badge {
    position: relative;

    &-img {
      width: 110px;
      height: 110px;
      object-fit: cover;
      border-radius: 46px 0 0 0;
    }

    &-text {
      position: absolute;
      top: 8px;
      right: 10px;
      font-family: 'Rubik', sans-serif;
      font-size: 16px;
      font-weight: 400;
      color: #fff;
      text-align: center;
      transform: rotate(44deg);
      transform-origin: center;
      line-height: 1;

      small {
        font-size: 9px;
        display: block;
      }
    }
  }

  &__bottle {
    width: 96px;
    height: 160px;
    object-fit: contain;
    filter: drop-shadow(-3px -5px 4px rgba(0,0,0,0.25)) drop-shadow(4px 4px 6px rgba(0,0,0,0.25));
    margin-top: 8px;
  }

  &__desc {
    font-family: 'Rubik', sans-serif;
    font-size: 14px;
    font-weight: 400;
    color: #fff;
    text-align: center;
    line-height: 90%;
    letter-spacing: -0.05em;
  }

  &__price {
    font-family: 'Rubik', sans-serif;
    font-size: 20px;
    font-weight: 400;
    color: #fff;
    display: flex;
    align-items: baseline;
    gap: 4px;
  }

  &__price-amount {
    font-size: 36px;
    line-height: 90%;
  }
}

.btn-order {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 48px;
  padding: 0 40px;
  border-radius: 16px;
  background: #FF7A2A;
  color: #000;
  font-family: 'Rubik', sans-serif;
  font-size: 16px;
  font-weight: 400;
  letter-spacing: -0.05em;
  text-decoration: none;
  cursor: pointer;
  transition: opacity 0.2s;

  &:hover {
    opacity: 0.9;
  }
}
</style>
