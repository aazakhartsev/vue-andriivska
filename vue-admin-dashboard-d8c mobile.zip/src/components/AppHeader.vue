<template>
  <header class="app-header">
    <div class="app-header__inner">
      <a href="#" class="app-header__logo">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/480323471cf7eae05d6e13b3013866ecf476e83c?width=154"
          alt="Андріївська логотип"
          width="77"
          height="50"
        />
      </a>

      <nav class="app-header__nav" :class="{ 'app-header__nav--open': menuOpen }">
        <a href="#about" class="app-header__nav-link" @click="closeMenu">Про нас</a>
        <a href="#prices" class="app-header__nav-link" @click="closeMenu">Ціни</a>
        <a href="#partners" class="app-header__nav-link" @click="closeMenu">Партнерам</a>
        <a href="tel:+380634908000" class="app-header__nav-phone">+38 (063) 490 8000</a>
      </nav>

      <button class="app-header__burger" @click="toggleMenu" aria-label="Меню">
        <svg v-if="!menuOpen" width="28" height="25" viewBox="0 0 28 25" fill="none">
          <path d="M0 12.5H28M0 25H28M0 0H28" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <svg v-else width="28" height="28" viewBox="0 0 28 28" fill="none">
          <path d="M2 2L26 26M26 2L2 26" stroke="white" stroke-width="3" stroke-linecap="round"/>
        </svg>
      </button>
    </div>
  </header>
</template>

<script>
export default {
  name: 'AppHeader',
  computed: {
    menuOpen() {
      return this.$store.getters['ui/isMenuOpen']
    },
  },
  methods: {
    toggleMenu() {
      this.$store.dispatch('ui/toggleMenu')
    },
    closeMenu() {
      this.$store.dispatch('ui/closeMenu')
    },
  },
}
</script>

<style scoped lang="scss">
.app-header {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: 100;
  padding: 20px 24px;

  &__inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
  }

  &__logo {
    display: block;
    flex-shrink: 0;

    img {
      width: 77px;
      height: 50px;
      object-fit: contain;
    }
  }

  &__nav {
    display: none;
    flex-direction: column;
    position: absolute;
    top: 90px;
    left: 0;
    right: 0;
    background: rgba(8, 99, 199, 0.97);
    padding: 24px;
    gap: 20px;
    border-top: 1px solid rgba(255,255,255,0.15);

    &--open {
      display: flex;
    }

    @media (min-width: 768px) {
      display: flex;
      flex-direction: row;
      position: static;
      background: none;
      padding: 0;
      align-items: center;
      gap: 32px;
      border-top: none;
    }
  }

  &__nav-link {
    color: #fff;
    font-family: 'Rubik', sans-serif;
    font-size: 16px;
    letter-spacing: -0.04em;
    text-decoration: none;
    opacity: 0.9;
    transition: opacity 0.2s;

    &:hover {
      opacity: 1;
    }
  }

  &__nav-phone {
    color: #fff;
    font-family: 'Rubik', sans-serif;
    font-size: 15px;
    letter-spacing: -0.04em;
    text-decoration: none;
    padding: 8px 20px;
    border-radius: 20px;
    background: rgba(255,255,255,0.12);
    transition: background 0.2s;

    &:hover {
      background: rgba(255,255,255,0.2);
    }
  }

  &__burger {
    background: none;
    border: none;
    cursor: pointer;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;

    @media (min-width: 768px) {
      display: none;
    }
  }
}
</style>
