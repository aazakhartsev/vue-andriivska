<template>
  <section class="certs">
    <div class="certs__inner">
      <h2 class="certs__title">
        <span class="text-white">Підтвердження </span>
        <span class="text-accent">якості</span>
      </h2>

      <div class="certs__showcase">
        <div class="certs__glow"></div>
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/9cf76e0722fd5e46fe5249bb3ff9700e2aaf6024?width=447"
          alt="Сертифікат відповідності"
          class="certs__cert-img"
        />
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'CertificatesSection',
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.certs {
  padding: 60px 0;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 32px;
    font-weight: 400;
    line-height: 104%;
    letter-spacing: -0.05em;
    text-align: center;
    margin-bottom: 40px;

    @media (min-width: 768px) {
      font-size: 40px;
    }
  }

  &__showcase {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 340px;
  }

  &__glow {
    position: absolute;
    width: 80%;
    max-width: 500px;
    height: 250px;
    background: #FF7A2A;
    border-radius: 50%;
    filter: blur(50px);
    opacity: 0.5;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  &__cert-img {
    position: relative;
    z-index: 2;
    width: 220px;
    height: auto;
    object-fit: contain;
    filter: drop-shadow(0 8px 24px rgba(0,0,0,0.4));
  }
}
</style>
