<template>
  <section class="water-quality" id="about">
    <div class="water-quality__inner">
      <h2 class="water-quality__title">
        <span class="text-white">М'який </span>
        <span class="text-accent">смак</span>
        <span class="text-white"> та унікальний мінеральний </span>
        <span class="text-accent">склад</span>
        <span class="text-white"> для </span>
        <span class="text-accent">щоденного вживання</span>
      </h2>

      <div class="analysis-card">
        <div class="analysis-card__header">
          <div class="analysis-card__header-left">
            <span class="analysis-card__label">аналіз Води</span>
            <span class="analysis-card__date">на дату 01.04.2026</span>
          </div>
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
            <path d="M20.9988 5.60034H25.1988V26.6003H2.79883V5.60034H6.99883V4.20034C6.99883 3.62634 7.20883 3.13634 7.61483 2.71634C8.02083 2.31034 8.52483 2.10034 9.09883 2.10034C9.67283 2.10034 10.1768 2.31034 10.5828 2.71634C10.9888 3.13634 11.1988 3.62634 11.1988 4.20034V5.60034H16.7988V4.20034C16.7988 3.62634 17.0088 3.13634 17.4148 2.71634C17.8208 2.31034 18.3248 2.10034 18.8988 2.10034C19.4728 2.10034 19.9768 2.31034 20.3828 2.71634C20.7888 3.13634 20.9988 3.62634 20.9988 4.20034V5.60034ZM8.39883 4.20034V7.70034C8.39692 7.79279 8.41372 7.88467 8.44823 7.97046C8.48273 8.05625 8.53422 8.13418 8.59961 8.19956C8.66499 8.26495 8.74292 8.31644 8.82871 8.35094C8.9145 8.38545 9.00638 8.40225 9.09883 8.40034C9.19128 8.40225 9.28316 8.38545 9.36895 8.35094C9.45474 8.31644 9.53266 8.26495 9.59805 8.19956C9.66343 8.13418 9.71493 8.05625 9.74943 7.97046C9.78393 7.88467 9.80073 7.79279 9.79883 7.70034V4.20034C9.79883 4.00434 9.72883 3.83634 9.58883 3.71034C9.46283 3.57034 9.29483 3.50034 9.09883 3.50034C8.90283 3.50034 8.73483 3.57034 8.60883 3.71034C8.46883 3.83634 8.39883 4.00434 8.39883 4.20034ZM18.1988 4.20034V7.70034C18.1988 7.89634 18.2688 8.06434 18.3948 8.20434C18.5348 8.33034 18.7028 8.40034 18.8988 8.40034C19.0948 8.40034 19.2628 8.33034 19.4028 8.20434C19.5288 8.06434 19.5988 7.89634 19.5988 7.70034V4.20034C19.6007 4.10789 19.5839 4.01601 19.5494 3.93022C19.5149 3.84443 19.4634 3.76651 19.398 3.70112C19.3327 3.63574 19.2547 3.58424 19.1689 3.54974C19.0832 3.51524 18.9913 3.49844 18.8988 3.50034C18.8064 3.49844 18.7145 3.51524 18.6287 3.54974C18.5429 3.58424 18.465 3.63574 18.3996 3.70112C18.3342 3.76651 18.2827 3.84443 18.2482 3.93022C18.2137 4.01601 18.1969 4.10789 18.1988 4.20034ZM23.7988 25.2003V11.2003H4.19883V25.2003H23.7988ZM9.79883 12.6003V15.4003H6.99883V12.6003H9.79883ZM12.5988 12.6003H15.3988V15.4003H12.5988V12.6003ZM18.1988 15.4003V12.6003H20.9988V15.4003H18.1988ZM9.79883 16.8003V19.6003H6.99883V16.8003H9.79883ZM12.5988 16.8003H15.3988V19.6003H12.5988V16.8003ZM18.1988 19.6003V16.8003H20.9988V19.6003H18.1988ZM9.79883 21.0003V23.8003H6.99883V21.0003H9.79883ZM15.3988 23.8003H12.5988V21.0003H15.3988V23.8003ZM20.9988 23.8003H18.1988V21.0003H20.9988V23.8003Z" fill="#FF7A2A"/>
          </svg>
        </div>

        <div class="analysis-table-wrap">
          <div class="analysis-table">
            <div class="analysis-table__head">
              <div class="analysis-table__col-name">Показник</div>
              <div class="analysis-table__col-norm">Нормативне значення</div>
              <div class="analysis-table__col-fact">Фактичне значення води «Андріївська»</div>
            </div>

            <div v-for="(row, index) in tableData" :key="index" class="analysis-table__row">
              <div class="analysis-table__col-name">{{ row.name }}</div>
              <div class="analysis-table__col-norm">{{ row.norm }}</div>
              <div class="analysis-table__col-fact">{{ row.fact }}</div>
            </div>
          </div>
        </div>

        <a href="#" class="analysis-card__link">Повний аналіз води</a>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'WaterQualitySection',
  data() {
    return {
      tableData: [
        { name: 'pH (кислотність)', norm: '6.5 - 8.5', fact: '8.3' },
        { name: 'Мінералізація мг/дм3', norm: 'Не нормується', fact: '72.5' },
        { name: 'Жорсткість ммоль/дм3', norm: '4.5', fact: '4.5' },
        { name: 'Кальцій (Ca²⁺) мг/дм3', norm: '25 - 75', fact: '4.01' },
        { name: 'Магній (Mg²⁺) мг/дм3', norm: '10 - 50', fact: '7.9' },
        { name: 'Сірководень та розчинені сульфіди', norm: 'не нормується', fact: 'не виявлено' },
        { name: 'Амоній ( NH₄⁺ ) мг/дм3', norm: 'не більше 0.5', fact: 'менше 0.003' },
        { name: 'Нітрити мг/дм3', norm: 'не більше 0.5', fact: 'менше 0.003' },
        { name: 'Нітрати мг/дм3', norm: 'не більше 50', fact: '0.78' },
        { name: 'Хлориди мг/дм3', norm: 'не більше 250', fact: 'менше 5' },
        { name: 'Сульфати мг/дм3', norm: 'не більше 250', fact: 'менше 2' },
        { name: 'Залізо мг/дм3', norm: 'не більше 0.2', fact: 'менше 0.05' },
        { name: 'Марганець мг/дм3', norm: 'не більше 0.5', fact: 'менше 0.005' },
      ],
    }
  },
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.water-quality {
  padding: 40px 0;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 32px;
    font-weight: 400;
    line-height: 90%;
    letter-spacing: -0.05em;
    text-align: center;
    margin-bottom: 32px;

    @media (min-width: 768px) {
      font-size: 40px;
    }

    @media (min-width: 1200px) {
      font-size: 48px;
    }
  }
}

.analysis-card {
  background: rgba(217, 217, 217, 0.20);
  border-radius: 22px;
  padding: 20px 16px;
  position: relative;
  overflow: hidden;

  @media (min-width: 768px) {
    padding: 28px 24px;
  }

  &__header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 20px;
  }

  &__header-left {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  &__label {
    font-family: 'Rubik', sans-serif;
    font-size: 16px;
    font-weight: 400;
    color: #fff;
    letter-spacing: -0.05em;
    text-transform: uppercase;
  }

  &__date {
    font-family: 'Rubik', sans-serif;
    font-size: 14px;
    font-weight: 500;
    color: #FF7A2A;
    letter-spacing: -0.05em;
  }

  &__link {
    display: block;
    font-family: 'Rubik', sans-serif;
    font-size: 14px;
    font-weight: 400;
    color: #fff;
    letter-spacing: -0.05em;
    text-align: right;
    text-decoration: underline;
    margin-top: 16px;
  }
}

.analysis-table-wrap {
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  margin: 0 -16px;
  padding: 0 16px;
}

.analysis-table {
  font-family: 'Rubik', sans-serif;
  font-size: 12px;
  font-weight: 400;
  letter-spacing: -0.05em;
  color: #fff;
  min-width: 300px;

  @media (min-width: 480px) {
    font-size: 13px;
  }

  @media (min-width: 768px) {
    font-size: 14px;
  }

  &__head {
    display: grid;
    grid-template-columns: 2fr 1.5fr 1.5fr;
    gap: 8px;
    padding: 8px 0;
    border-bottom: 1px solid rgba(255,255,255,0.3);
    font-weight: 500;
    margin-bottom: 4px;
  }

  &__row {
    display: grid;
    grid-template-columns: 2fr 1.5fr 1.5fr;
    gap: 8px;
    padding: 8px 0;
    border-bottom: 1px solid rgba(255,255,255,0.15);

    &:last-child {
      border-bottom: none;
    }
  }

  &__col-name,
  &__col-norm,
  &__col-fact {
    line-height: 1.3;
  }
}
</style>
