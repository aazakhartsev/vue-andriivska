<template>
  <section class="eco">
    <div class="eco__inner">
      <h2 class="eco__title">
        <span class="text-white">Вода, що працює на </span>
        <span class="text-accent">сонці</span>
      </h2>

      <div class="eco__cards">
        <!-- Electric delivery card -->
        <div class="eco-card">
          <div class="eco-card__top">
            <img
              class="eco-card__icon"
              src="https://api.builder.io/api/v1/image/assets/TEMP/18f2232dcd3ee53c6330c546ce0c4423df7d1e6c?width=85"
              alt="Електромобіль"
            />
          </div>
          <img
            class="eco-card__main-img"
            src="https://api.builder.io/api/v1/image/assets/TEMP/d5797ff586fcb1a5326b4e6ae66ddb9960d5b209?width=514"
            alt="Електромобіль доставки"
          />
          <p class="eco-card__desc">
            Доставляємо виключно <span class="text-accent">електротранспортом</span>
          </p>
        </div>

        <!-- Connector symbol -->
        <div class="eco__connector">
          <svg width="33" height="37" viewBox="0 0 33 37" fill="none">
            <path d="M16.6514 0L16.6514 37" stroke="white" stroke-opacity="0.3" stroke-width="4.93333" stroke-linecap="round"/>
            <path d="M32.0664 19.1162L-0.000263929 19.1162" stroke="white" stroke-opacity="0.3" stroke-width="4.93333" stroke-linecap="round"/>
          </svg>
        </div>

        <!-- Solar energy card -->
        <div class="eco-card">
          <img
            class="eco-card__solar-img"
            src="https://api.builder.io/api/v1/image/assets/TEMP/53a786c54fe8ef827f76fe6d0483ec702e7b0545?width=446"
            alt="Сонячні панелі"
          />
          <p class="eco-card__desc">
            На <span class="text-accent">100%</span> самі забезпечуємо себе <span class="text-accent">електроенергією</span>
          </p>
          <div class="eco-card__energy-icon">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
              <path d="M23.9631 43.9319C34.9917 43.9319 43.9321 34.9915 43.9321 23.9629C43.9321 12.9343 34.9917 3.9939 23.9631 3.9939C12.9346 3.9939 3.99414 12.9343 3.99414 23.9629C3.99414 34.9915 12.9346 43.9319 23.9631 43.9319Z" stroke="white" stroke-opacity="0.2" stroke-width="1.85518"/>
              <path d="M16.2331 23.1602L24.2187 12.397C24.8438 11.5543 26.0139 12.0775 26.0139 13.1997V21.5308C26.0139 22.2017 26.4732 22.7469 27.0404 22.7469H30.9223C31.805 22.7469 32.2762 23.981 31.6931 24.7658L23.7075 35.529C23.0825 36.3717 21.9123 35.8486 21.9123 34.7263V26.3952C21.9123 25.7243 21.453 25.1791 20.8859 25.1791H17.0039C16.1233 25.1791 15.652 23.945 16.2351 23.1602" stroke="white" stroke-opacity="0.2" stroke-width="2.47358" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'EcoSection',
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.eco {
  padding: 60px 0 20px;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 32px;
    font-weight: 400;
    line-height: 90%;
    letter-spacing: -0.05em;
    text-align: center;
    margin-bottom: 40px;

    @media (min-width: 768px) {
      font-size: 40px;
    }
  }

  &__cards {
    display: flex;
    flex-direction: column;
    gap: 20px;
    align-items: center;

    @media (min-width: 768px) {
      flex-direction: row;
      justify-content: center;
      align-items: center;
      gap: 20px;
    }
  }

  &__connector {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-shrink: 0;
  }
}

.eco-card {
  background: rgba(217, 217, 217, 0.20);
  border-radius: 30px;
  padding: 10px;
  width: 100%;
  max-width: 266px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  overflow: hidden;
  min-height: 244px;

  &__top {
    padding: 4px 4px 0;
  }

  &__icon {
    width: 42px;
    height: 48px;
    object-fit: contain;
  }

  &__main-img {
    width: 100%;
    height: auto;
    object-fit: cover;
    border-radius: 12px;
  }

  &__solar-img {
    width: 100%;
    height: 148px;
    object-fit: cover;
    transform: rotate(-168deg);
    box-shadow: 3px 9px 11px rgba(0,0,0,0.74);
    border-radius: 12px;
  }

  &__desc {
    font-family: 'Rubik', sans-serif;
    font-size: 16px;
    font-weight: 400;
    color: #fff;
    line-height: 90%;
    letter-spacing: -0.05em;
    padding: 0 8px 4px;
  }

  &__energy-icon {
    display: flex;
    justify-content: flex-end;
    padding: 0 4px 4px 0;
  }
}
</style>
