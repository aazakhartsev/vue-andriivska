<template>
  <section class="clients">
    <div class="clients__inner">
      <h2 class="clients__title">
        <span class="text-white">Наші </span>
        <span class="text-accent">клієнти</span>
      </h2>

      <div class="clients__logos">
        <button class="clients__nav clients__nav--prev" aria-label="Попередній">
          <svg width="25" height="25" viewBox="0 0 25 25" fill="none">
            <rect width="24.7456" height="24.7456" rx="6.00965" fill="#D9D9D9" fill-opacity="0.2"/>
            <path d="M14.5205 6.60028L9.24021 12.9562L14.5205 18.481" stroke="white" stroke-width="0.682133"/>
          </svg>
        </button>

        <div class="clients__logo-grid">
          <div v-for="(client, index) in clients" :key="index" class="client-logo">
            <img :src="client.logo" :alt="client.name" />
          </div>
        </div>

        <button class="clients__nav clients__nav--next" aria-label="Наступний">
          <svg width="25" height="25" viewBox="0 0 25 25" fill="none">
            <rect width="24.75" height="24.75" rx="5.82857" transform="matrix(-1 0 0 1 24.75 0)" fill="#D9D9D9" fill-opacity="0.2"/>
            <path d="M9.71191 6.4018L14.8332 12.5664L9.71191 17.9248" stroke="white" stroke-width="0.661579"/>
          </svg>
        </button>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'ClientsSection',
  data() {
    return {
      clients: [
        {
          name: 'Артем',
          logo: 'https://api.builder.io/api/v1/image/assets/TEMP/8cb5732a1820fb3257402ad267a92b11c8007d2e?width=170',
        },
        {
          name: 'Winner',
          logo: 'https://api.builder.io/api/v1/image/assets/TEMP/37652a58e1e4837adc402db76a7ba68af024e29b?width=169',
        },
        {
          name: 'ПФТС',
          logo: 'https://api.builder.io/api/v1/image/assets/TEMP/32d0b7d567500e1ce9e158d3499d15f28cb27f7a?width=176',
        },
      ],
    }
  },
}
</script>

<style scoped lang="scss">
.text-white { color: #fff; }
.text-accent { color: #FF7A2A; }

.clients {
  padding: 60px 0;

  &__inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
  }

  &__title {
    font-family: 'Rubik', sans-serif;
    font-size: 32px;
    font-weight: 400;
    line-height: 104%;
    letter-spacing: -0.05em;
    text-align: center;
    margin-bottom: 32px;

    @media (min-width: 768px) {
      font-size: 40px;
    }
  }

  &__logos {
    display: flex;
    align-items: center;
    gap: 12px;
    justify-content: center;
  }

  &__nav {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    flex-shrink: 0;
    opacity: 0.8;
    transition: opacity 0.2s;

    &:hover {
      opacity: 1;
    }
  }

  &__logo-grid {
    display: flex;
    gap: 8px;
    flex: 1;
    justify-content: center;
    flex-wrap: wrap;

    @media (min-width: 768px) {
      gap: 12px;
      flex-wrap: nowrap;
    }
  }
}

.client-logo {
  background: rgba(217, 217, 217, 0.20);
  border-radius: 22px;
  padding: 16px 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 96px;
  height: 70px;
  flex-shrink: 0;

  img {
    max-width: 80px;
    max-height: 32px;
    object-fit: contain;
    filter: brightness(1) invert(0);
  }
}
</style>
