<template>
  <footer class="footer">
    <div class="footer__bg">
      <div class="footer__bg-shape"></div>
    </div>

    <div class="footer__inner">
      <div class="footer__logo">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/480323471cf7eae05d6e13b3013866ecf476e83c?width=154"
          alt="Андріївська"
          width="77"
          height="50"
        />
      </div>

      <nav class="footer__nav">
        <a href="#about" class="footer__nav-link">Про нас</a>
        <a href="#prices" class="footer__nav-link">Ціни</a>
        <a href="#partners" class="footer__nav-link">Партнерам</a>
      </nav>

      <div class="footer__contacts">
        <a href="tel:+380634908000" class="footer__phone">
          +38 (063) 490 8000
        </a>

        <div class="footer__social">
          <!-- Instagram -->
          <a href="#" class="footer__social-link" aria-label="Instagram">
            <div class="footer__social-icon">
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.5 9C5.5 7.067 7.067 5.5 9 5.5C10.933 5.5 12.5 7.067 12.5 9C12.5 10.933 10.933 12.5 9 12.5C7.067 12.5 5.5 10.933 5.5 9ZM9 7.5C8.172 7.5 7.5 8.172 7.5 9C7.5 9.828 8.172 10.5 9 10.5C9.828 10.5 10.5 9.828 10.5 9C10.5 8.172 9.828 7.5 9 7.5Z" fill="white"/>
                <path d="M12.75 5.25C12.75 5.664 12.414 6 12 6C11.586 6 11.25 5.664 11.25 5.25C11.25 4.836 11.586 4.5 12 4.5C12.414 4.5 12.75 4.836 12.75 5.25Z" fill="white"/>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M2.5 9C2.5 6.1 2.5 4.65 3.075 3.525C3.583 2.538 4.388 1.733 5.375 1.225C6.5 0.65 7.95 0.65 10.85 0.65C13.75 0.65 15.2 0.65 16.325 1.225C17.312 1.733 18.117 2.538 18.625 3.525C19.2 4.65 19.2 6.1 19.2 9C19.2 11.9 19.2 13.35 18.625 14.475C18.117 15.462 17.312 16.267 16.325 16.775C15.2 17.35 13.75 17.35 10.85 17.35H7.15C4.25 17.35 2.8 17.35 1.675 16.775C0.688 16.267 -0.117 15.462 -0.625 14.475C-1.2 13.35 -1.2 11.9 -1.2 9C-1.2 6.1 -1.2 4.65 -0.625 3.525C-0.117 2.538 0.688 1.733 1.675 1.225" stroke="white" stroke-width="1" opacity="0"/>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.5 1.5C2.672 1.5 2 2.172 2 3V15C2 15.828 2.672 16.5 3.5 16.5H14.5C15.328 16.5 16 15.828 16 15V3C16 2.172 15.328 1.5 14.5 1.5H3.5ZM0 3C0 1.067 1.567 -0.5 3.5 -0.5H14.5C16.433 -0.5 18 1.067 18 3V15C18 16.933 16.433 18.5 14.5 18.5H3.5C1.567 18.5 0 16.933 0 15V3Z" fill="white" opacity="0"/>
              </svg>
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="white" stroke-width="1.5">
                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
                <circle cx="12" cy="12" r="4.5"/>
                <circle cx="17.5" cy="6.5" r="0.7" fill="white" stroke="none"/>
              </svg>
            </div>
          </a>

          <!-- Facebook -->
          <a href="#" class="footer__social-link" aria-label="Facebook">
            <div class="footer__social-icon">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
              </svg>
            </div>
          </a>

          <!-- LinkedIn -->
          <a href="#" class="footer__social-link" aria-label="LinkedIn">
            <div class="footer__social-icon">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/>
                <rect x="2" y="9" width="4" height="12"/>
                <circle cx="4" cy="4" r="2"/>
              </svg>
            </div>
          </a>
        </div>
      </div>

      <p class="footer__copy">Андріївська © 2026. Всі права захищені.</p>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'AppFooter',
}
</script>

<style scoped lang="scss">
.footer {
  position: relative;
  overflow: hidden;
  background: #02438A;
  padding: 0 0 32px;

  &__bg {
    position: absolute;
    inset: 0;
    pointer-events: none;
  }

  &__bg-shape {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: #002C5C;
    clip-path: polygon(
      -5% 6%,
      25% 0%,
      105% 10%,
      105% 100%,
      -5% 100%
    );
  }

  &__inner {
    position: relative;
    z-index: 2;
    max-width: 1200px;
    margin: 0 auto;
    padding: 48px 24px 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 24px;
  }

  &__logo {
    img {
      width: 77px;
      height: 50px;
      object-fit: contain;
    }
  }

  &__nav {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 16px;

    @media (min-width: 768px) {
      flex-direction: row;
      gap: 32px;
    }
  }

  &__nav-link {
    font-family: 'Rubik', sans-serif;
    font-size: 14px;
    font-weight: 400;
    color: #fff;
    text-decoration: none;
    letter-spacing: -0.05em;
    opacity: 0.9;
    transition: opacity 0.2s;

    &:hover {
      opacity: 1;
    }
  }

  &__contacts {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 16px;

    @media (min-width: 768px) {
      flex-direction: row;
      gap: 24px;
    }
  }

  &__phone {
    font-family: 'Rubik', sans-serif;
    font-size: 13px;
    font-weight: 400;
    color: #fff;
    text-decoration: none;
    letter-spacing: -0.05em;
    padding: 7px 16px;
    border-radius: 22px;
    background: rgba(255, 255, 255, 0.10);
    transition: background 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.18);
    }
  }

  &__social {
    display: flex;
    gap: 12px;
    align-items: center;
  }

  &__social-link {
    text-decoration: none;
  }

  &__social-icon {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.2);
    }
  }

  &__copy {
    font-family: 'Rubik', sans-serif;
    font-size: 10px;
    font-weight: 400;
    color: rgba(255, 255, 255, 0.7);
    letter-spacing: -0.05em;
    text-align: center;
  }
}
</style>
