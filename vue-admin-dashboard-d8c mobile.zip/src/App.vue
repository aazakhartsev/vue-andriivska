<template>
  <div id="andriyivska-app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>
#andriyivska-app {
  min-height: 100vh;
  background-color: #0863C7;
  font-family: 'Rubik', sans-serif;
}
</style>
