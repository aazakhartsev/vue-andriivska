<template>
  <div class="home">
    <AppHeader />

    <main class="home__main">
      <HeroSection />
      <WaterJourneySection />
      <WaterQualitySection />
      <EcoSection />
      <PriceSection />
      <QualityProtectionSection />
      <CertificatesSection />
      <DocumentSection />
      <ClientsSection />
      <PartnerSection />
    </main>

    <AppFooter />
  </div>
</template>

<script>
import AppHeader from '../components/AppHeader.vue'
import HeroSection from '../components/HeroSection.vue'
import WaterJourneySection from '../components/WaterJourneySection.vue'
import WaterQualitySection from '../components/WaterQualitySection.vue'
import EcoSection from '../components/EcoSection.vue'
import PriceSection from '../components/PriceSection.vue'
import QualityProtectionSection from '../components/QualityProtectionSection.vue'
import CertificatesSection from '../components/CertificatesSection.vue'
import DocumentSection from '../components/DocumentSection.vue'
import ClientsSection from '../components/ClientsSection.vue'
import PartnerSection from '../components/PartnerSection.vue'
import AppFooter from '../components/AppFooter.vue'

export default {
  name: 'HomeView',
  components: {
    AppHeader,
    HeroSection,
    WaterJourneySection,
    WaterQualitySection,
    EcoSection,
    PriceSection,
    QualityProtectionSection,
    CertificatesSection,
    DocumentSection,
    ClientsSection,
    PartnerSection,
    AppFooter,
  },
}
</script>

<style scoped lang="scss">
.home {
  background-color: #0863C7;
  min-height: 100vh;

  &__main {
    overflow-x: hidden;
  }
}
</style>
