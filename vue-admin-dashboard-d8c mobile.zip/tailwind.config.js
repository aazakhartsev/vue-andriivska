/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#0863C7',
        accent: '#FF7A2A',
        navy: '#002C5C',
        'navy-2': '#02438A',
        'card-bg': 'rgba(217, 217, 217, 0.20)',
        'teal-light': '#CADECF',
      },
      fontFamily: {
        rubik: ['Rubik', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
