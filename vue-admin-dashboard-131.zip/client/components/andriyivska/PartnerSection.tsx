import { useState } from "react";

export default function PartnerSection() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  return (
    <section className="py-16 md:py-24 px-4 md:px-8 lg:px-16" id="partners">
      <div className="max-w-[1440px] mx-auto">
        {/* Title */}
        <div className="text-center mb-12 md:mb-20">
          <h2 className="font-rubik font-normal text-4xl sm:text-5xl md:text-6xl lg:text-[80px] leading-[104%] tracking-[-4px]">
            <span className="text-[#FF7A2A]">Партнерська</span>
            <span className="text-white"> мережа</span>
          </h2>
        </div>

        <div className="flex flex-col lg:flex-row gap-10 lg:gap-16 items-center">
          {/* Left: stand image + info */}
          <div className="flex-shrink-0 relative w-full max-w-[400px] mx-auto lg:mx-0">
            {/* Orange glow */}
            <div
              className="absolute inset-0 rounded-full"
              style={{
                background: '#FF7A2A',
                filter: 'blur(167px)',
                opacity: 0.5,
              }}
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/f695e9152b573323f71e2390cff716cefc5ce310?width=230"
              alt=""
              className="absolute top-10 right-10 w-12 h-auto z-20 opacity-70"
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/0222148f695a66d51b96992c98f8fdf28caecbec?width=1228"
              alt="Стійка з бутлями"
              className="relative z-10 w-full h-auto"
            />
          </div>

          {/* Right: partner info + form */}
          <div className="flex-1 space-y-6 md:space-y-8">
            {/* Question */}
            <p className="text-white font-rubik font-normal text-2xl md:text-3xl lg:text-[50px] leading-[104%] tracking-[-2.5px]">
              Маєте бізнес-центр, ОСББ чи будинок з охороною?
            </p>

            {/* Steps */}
            <p className="text-white font-rubik font-normal text-2xl md:text-3xl lg:text-[50px] leading-[104%] tracking-[-2.5px]">
              Встановлюйте наші стійки з бутлями
            </p>

            {/* Earnings */}
            <div className="bg-white/20 rounded-3xl p-6 md:p-8 text-center">
              <p className="text-white font-rubik font-normal text-2xl md:text-3xl lg:text-[50px] leading-[80%]">
                отримуйте
              </p>
              <p className="font-rubik font-normal leading-[80%] mt-2">
                <span className="text-[#FF7A2A] text-6xl md:text-8xl lg:text-[120px]">10</span>
                <span className="text-[#FF7A2A] text-5xl md:text-7xl lg:text-[100px]">%</span>
              </p>
              <p className="text-white font-rubik font-normal text-2xl md:text-3xl lg:text-[50px] leading-[80%] mt-2">
                від продажів
              </p>
            </div>

            {/* Partner form */}
            <div className="bg-white/20 rounded-[30px] p-6 md:p-8 space-y-4">
              <div className="bg-white rounded-xl px-5 py-3">
                <input
                  type="text"
                  placeholder="Ім'я *"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-transparent text-black font-rubik text-lg md:text-xl tracking-tight outline-none"
                />
              </div>
              <div className="bg-white rounded-xl px-5 py-3">
                <input
                  type="tel"
                  placeholder="+380 (__) ___ __ __ *"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-transparent text-black font-rubik text-lg md:text-xl tracking-tight outline-none"
                />
              </div>
              <button className="w-full bg-[#FF7A2A] hover:bg-[#e66a1a] transition-colors text-black font-rubik font-normal text-base md:text-lg tracking-tight px-6 py-3 rounded-[30px]">
                Стати партнером
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
