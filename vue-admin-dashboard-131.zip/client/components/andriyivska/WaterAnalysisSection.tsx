const analysisData = [
  { name: "pH (кислотність)", norm: "6.5 - 8.5", value: "8.3" },
  { name: "Мінералізація, мг/дм³", norm: "Не нормується", value: "72.5" },
  { name: "Жорсткість, ммоль/дм³", norm: "4.5", value: "4.5" },
  { name: "Кальцій (Ca²⁺), мг/дм³", norm: "25 - 75", value: "4.01" },
  { name: "Магній (Mg²⁺), мг/дм³", norm: "10 - 50", value: "7.9" },
  { name: "Сірководень та розчинені сульфіди", norm: "не нормується", value: "не виявлено" },
  { name: "Амоній (NH₄⁺), мг/дм³", norm: "не більше 0.5", value: "менше 0.003" },
  { name: "Нітрити, мг/дм³", norm: "не більше 0.5", value: "менше 0.003" },
  { name: "Нітрати, мг/дм³", norm: "не більше 50", value: "0.78" },
  { name: "Хлориди, мг/дм³", norm: "не більше 250", value: "менше 5" },
  { name: "Сульфати, мг/дм³", norm: "не більше 250", value: "менше 2" },
  { name: "Залізо, мг/дм³", norm: "не більше 0.2", value: "менше 0.05" },
  { name: "Марганець, мг/дм³", norm: "не більше 0.5", value: "менше 0.005" },
];

export default function WaterAnalysisSection() {
  return (
    <section className="py-16 md:py-24 px-4 md:px-8 lg:px-16" id="about">
      <div className="max-w-[1440px] mx-auto">
        {/* Tagline */}
        <div className="text-center mb-10 md:mb-16">
          <h2 className="font-rubik font-normal text-4xl sm:text-5xl md:text-6xl lg:text-[80px] leading-[90%] tracking-[-4px]">
            <span className="text-white">М'який </span>
            <span className="text-[#FF7A2A]">смак</span>
            <span className="text-white"> та унікальний мінеральний </span>
            <span className="text-[#FF7A2A]">склад</span>
            <span className="text-white"> для </span>
            <span className="text-[#FF7A2A]">щоденного вживання</span>
          </h2>
        </div>

        {/* Analysis table */}
        <div className="bg-white/20 backdrop-blur-sm rounded-[40px] md:rounded-[72px] p-4 md:p-8 lg:p-12">
          {/* Header */}
          <div className="flex items-start justify-between mb-6 md:mb-8 flex-wrap gap-4">
            <div>
              <h3 className="text-white font-rubik font-normal text-2xl md:text-4xl lg:text-[50px] leading-[90%] tracking-[-2.5px]">
                Аналіз води
              </h3>
              <p className="text-[#FF7A2A] font-rubik font-normal text-xl md:text-3xl lg:text-[46px] leading-[90%] tracking-[-2.3px] underline mt-2">
                на дату 01.04.2026
              </p>
            </div>
            <svg width="70" height="70" viewBox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0">
              <path d="M52.4961 14.001H62.9961V66.501H6.99609V14.001H17.4961V10.501C17.4961 9.06598 18.0211 7.84098 19.0361 6.79098C20.0511 5.77598 21.3111 5.25098 22.7461 5.25098C24.1811 5.25098 25.4411 5.77598 26.4561 6.79098C27.4711 7.84098 27.9961 9.06598 27.9961 10.501V14.001H41.9961V10.501C41.9961 9.06598 42.5211 7.84098 43.5361 6.79098C44.5511 5.77598 45.8111 5.25098 47.2461 5.25098C48.6811 5.25098 49.9411 5.77598 50.9561 6.79098C51.9711 7.84098 52.4961 9.06598 52.4961 10.501V14.001ZM20.9961 10.501V19.251C20.9913 19.4821 21.0333 19.7118 21.1196 19.9263C21.2059 20.1407 21.3346 20.3356 21.498 20.499C21.6615 20.6625 21.8563 20.7912 22.0708 20.8775C22.2853 20.9637 22.515 21.0057 22.7461 21.001C22.9772 21.0057 23.2069 20.9637 23.4214 20.8775C23.6359 20.7912 23.8307 20.6625 23.9941 20.499C24.1576 20.3356 24.2863 20.1407 24.3726 19.9263C24.4589 19.7118 24.5009 19.4821 24.4961 19.251V10.501C24.4961 10.011 24.3211 9.59098 23.9711 9.27598C23.6561 8.92598 23.2361 8.75098 22.7461 8.75098C22.2561 8.75098 21.8361 8.92598 21.5211 9.27598C21.1711 9.59098 20.9961 10.011 20.9961 10.501ZM45.4961 10.501V19.251C45.4961 19.741 45.6711 20.161 45.9861 20.511C46.3361 20.826 46.7561 21.001 47.2461 21.001C47.7361 21.001 48.1561 20.826 48.5061 20.511C48.8211 20.161 48.9961 19.741 48.9961 19.251V10.501C49.0009 10.2699 48.9589 10.0402 48.8726 9.82568C48.7863 9.61121 48.6576 9.41639 48.4941 9.25292C48.3307 9.08946 48.1359 8.96073 47.9214 8.87448C47.7069 8.78822 47.4772 8.74621 47.2461 8.75098C47.015 8.74621 46.7853 8.78822 46.5708 8.87448C46.3563 8.96073 46.1615 9.08946 45.998 9.25292C45.8346 9.41639 45.7059 9.61121 45.6196 9.82568C45.5333 10.0402 45.4913 10.2699 45.4961 10.501ZM59.4961 63.001V28.001H10.4961V63.001H59.4961ZM24.4961 31.501V38.501H17.4961V31.501H24.4961ZM31.4961 31.501H38.4961V38.501H31.4961V31.501ZM45.4961 38.501V31.501H52.4961V38.501H45.4961ZM24.4961 42.001V49.001H17.4961V42.001H24.4961ZM31.4961 42.001H38.4961V49.001H31.4961V42.001ZM45.4961 49.001V42.001H52.4961V49.001H45.4961ZM24.4961 52.501V59.501H17.4961V52.501H24.4961ZM38.4961 59.501H31.4961V52.501H38.4961V59.501ZM52.4961 59.501H45.4961V52.501H52.4961V59.501Z" fill="#FF7A2A"/>
            </svg>
          </div>

          {/* Table header */}
          <div className="grid grid-cols-3 gap-4 border-b border-white/30 pb-3 mb-2">
            <div className="text-white font-rubik font-semibold text-sm md:text-xl lg:text-2xl tracking-tight">
              Показник
            </div>
            <div className="text-white font-rubik font-semibold text-sm md:text-xl lg:text-2xl tracking-tight text-center">
              Нормативне значення
            </div>
            <div className="text-white font-rubik font-semibold text-sm md:text-xl lg:text-2xl tracking-tight text-right">
              Фактичне значення «Андріївська»
            </div>
          </div>

          {/* Table rows */}
          <div className="divide-y divide-white/20">
            {analysisData.map((row, i) => (
              <div key={i} className="grid grid-cols-3 gap-4 py-3 md:py-4">
                <div className="text-white font-rubik text-xs sm:text-sm md:text-lg lg:text-xl tracking-tight">
                  {row.name}
                </div>
                <div className="text-white font-rubik text-xs sm:text-sm md:text-lg lg:text-xl tracking-tight text-center">
                  {row.norm}
                </div>
                <div className="text-white font-rubik text-xs sm:text-sm md:text-lg lg:text-xl tracking-tight text-right">
                  {row.value}
                </div>
              </div>
            ))}
          </div>

          {/* Full analysis link */}
          <div className="text-center mt-8">
            <button className="text-white font-rubik text-2xl md:text-4xl lg:text-[50px] leading-[90%] tracking-[-2.5px] underline hover:text-[#FF7A2A] transition-colors">
              Повний аналіз води
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
