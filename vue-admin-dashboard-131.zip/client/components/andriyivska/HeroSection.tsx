export default function HeroSection() {
  return (
    <section className="relative min-h-screen overflow-hidden">
      {/* Background city image */}
      <div className="absolute inset-0">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/a0762713f278d236dbd14862755dda3fe6cb673e?width=4216"
          alt="Андріївська 1"
          className="w-full h-full object-cover object-center opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#033873]/80" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Top right water bottle branding */}
        <div className="flex justify-end px-6 md:px-16 pt-36 md:pt-44 lg:pt-52">
          <div className="flex flex-col items-end gap-3 max-w-[220px]">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/9c3305582ab5bf491619e1620648ed4badb992a6?width=298"
              alt="Для щоденного споживання"
              className="w-[149px] h-auto"
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/b5be25e8bcc509d9a6db2239f1e2622e40a7e15b?width=424"
              alt="Вона має мʼякий смак та унікальний склад мінералів"
              className="w-[212px] h-auto"
            />
          </div>
        </div>

        {/* Bottom left water logo */}
        <div className="flex-1 flex items-end px-6 md:px-16 pb-16 md:pb-24">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/d66fc5de02f91dfd72f295db8901ac536f32b8f9?width=606"
            alt="Андріївська"
            className="w-[200px] md:w-[250px] lg:w-[303px] h-auto"
          />
        </div>
      </div>

      {/* Feature Cards Row */}
      <div className="relative z-10 px-4 md:px-8 lg:px-16 pb-16 md:pb-20">
        <div className="max-w-[1920px] mx-auto grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
          <FeatureCard
            icon={
              <svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M35.7247 14.5198C38.1734 16.9516 39.8449 20.0559 40.527 23.4389C41.209 26.822 40.8711 30.3314 39.5559 33.5221C38.2408 36.7128 36.0077 39.441 33.1399 41.3609C30.272 43.2807 26.8987 44.3056 23.4475 44.3056C19.9964 44.3056 16.623 43.2807 13.7552 41.3609C10.8874 39.441 8.65427 36.7128 7.33912 33.5221C6.02398 30.3314 5.68602 26.822 6.36811 23.4389C7.0502 20.0559 8.72162 16.9516 11.1704 14.5198L23.447 2.64374L35.7247 14.5198Z" stroke="white" strokeWidth="2.08333" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M29.1562 21.3988C30.2946 22.5296 31.0716 23.973 31.3887 25.5459C31.7057 27.1189 31.5485 28.7505 30.937 30.234C30.3254 31.7175 29.2871 32.986 27.9537 33.8785C26.6203 34.7711 25.0519 35.2476 23.4473 35.2476C21.8427 35.2476 20.2743 34.7711 18.9409 33.8785C17.6075 32.986 16.5691 31.7175 15.9576 30.234C15.3461 28.7505 15.1889 27.1189 15.5059 25.5459C15.8229 23.973 16.5999 22.5296 17.7384 21.3988L23.4478 15.8763L29.1562 21.3988Z" stroke="white" strokeWidth="2.08333" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            }
            title="Ультрачиста вода"
            description="збагачена всіма необхідними мінералами"
          />
          <FeatureCard
            icon={
              <svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M25.5198 11.2604L15.1357 26.2299L22.4198 26.0106L21.4798 35.7396L31.8638 20.7701L24.5798 20.9894L25.5198 11.2604Z" stroke="white" strokeWidth="2.08333" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M23.4998 44.5521C35.1266 44.5521 44.5519 35.1268 44.5519 23.5C44.5519 11.8733 35.1266 2.44794 23.4998 2.44794C11.8731 2.44794 2.44775 11.8733 2.44775 23.5C2.44775 35.1268 11.8731 44.5521 23.4998 44.5521Z" stroke="white" strokeWidth="2.08333" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            }
            title="Іноваційна логістика"
            description="доставка виключно електротранспортом"
          />
          <FeatureCard
            icon={
              <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M23.9971 33.433C29.2095 33.433 33.4351 29.2075 33.4351 23.995C33.4351 18.7825 29.2095 14.557 23.9971 14.557C18.7846 14.557 14.5591 18.7825 14.5591 23.995C14.5591 29.2075 18.7846 33.433 23.9971 33.433Z" stroke="white" strokeWidth="2.08333" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2.5 23.995H9.846M23.997 45.5V38.15M23.997 9.85V2.5M38.154 23.995H45.5M8.79 39.192L13.985 33.998M39.2 39.2L34.002 34.002M13.989 13.991L8.79 8.794M34.002 13.984L39.196 8.79" stroke="white" strokeWidth="2.08333" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            }
            title="Енергія сонця"
            description="100% забезпечення себе електроенергією"
          />
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-[39px] p-6 md:p-8 flex flex-col items-center text-center gap-3">
      <div className="mb-2">{icon}</div>
      <h3 className="text-[#FF7A2A] font-rubik text-xl md:text-2xl font-normal leading-tight tracking-tight">
        {title}
      </h3>
      <p className="text-white font-rubik text-sm md:text-base leading-tight tracking-tight">
        {description}
      </p>
    </div>
  );
}
