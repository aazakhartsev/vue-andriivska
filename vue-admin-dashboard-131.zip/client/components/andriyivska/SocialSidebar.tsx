export default function SocialSidebar() {
  return (
    <div className="fixed left-4 md:left-8 top-1/2 transform -translate-y-1/2 z-40 hidden lg:flex flex-col gap-4">
      {/* Instagram */}
      <a
        href="#"
        className="w-[59px] h-[59px] rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path fillRule="evenodd" clipRule="evenodd" d="M35.1347 18.304C31.0576 17.8518 26.9431 17.8518 22.866 18.304C20.5187 18.5665 18.6228 20.4156 18.3475 22.7746C17.8646 26.91 17.8646 31.0876 18.3475 35.223C18.6228 37.582 20.5175 39.4311 22.866 39.6936C26.9431 40.1449 31.0576 40.1449 35.1347 39.6936C37.482 39.4311 39.3778 37.582 39.6532 35.223C40.1361 31.0876 40.1361 26.91 39.6532 22.7746C39.3778 20.4156 37.4832 18.5665 35.1347 18.304ZM23.0597 20.0423C27.008 19.6045 30.9927 19.6045 34.941 20.0423C36.4927 20.2173 37.7352 21.4411 37.916 22.9788C38.384 26.9785 38.384 31.0191 37.916 35.0188C37.8225 35.7714 37.478 36.4704 36.9382 37.003C36.3983 37.5356 35.6947 37.8707 34.941 37.9541C30.9927 38.392 27.008 38.392 23.0597 37.9541C22.3059 37.8707 21.6023 37.5356 21.0625 37.003C20.5227 36.4704 20.1782 35.7714 20.0847 35.0188C19.6167 31.0191 19.6167 26.9785 20.0847 22.9788C20.1782 22.2263 20.5227 21.5272 21.0625 20.9946C21.6023 20.462 22.3059 20.1257 23.0597 20.0423Z" fill="white"/>
          <circle cx="29" cy="28" r="5" stroke="white" strokeWidth="1.75"/>
          <circle cx="35.833" cy="22.167" r="1.2" fill="white"/>
        </svg>
      </a>

      {/* Facebook */}
      <a
        href="#"
        className="w-[59px] h-[59px] rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M22 0H18.7273C17.2806 0 15.8933 0.5795 14.8703 1.611C13.8474 2.6424 13.2727 4.0414 13.2727 5.5V8.8H10V13.2H13.2727V22H17.6364V13.2H20.9091L22 8.8H17.6364V5.5C17.6364 5.2083 17.7513 4.9285 17.9559 4.7222C18.1605 4.5159 18.4379 4.4 18.7273 4.4H22V0Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </a>

      {/* LinkedIn */}
      <a
        href="#"
        className="w-[59px] h-[59px] rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
      >
        <svg width="24" height="24" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M5.6875 8.938C5.6875 9.534 5.9246 10.107 6.3465 10.529C6.7685 10.95 7.3408 11.188 7.9375 11.188C8.5342 11.188 9.1065 10.95 9.5285 10.529C9.9504 10.107 10.1875 9.534 10.1875 8.938C10.1875 8.341 9.9504 7.769 9.5285 7.347C9.1065 6.925 8.5342 6.688 7.9375 6.688C7.3408 6.688 6.7685 6.925 6.3465 7.347C5.9246 7.769 5.6875 8.341 5.6875 8.938Z" stroke="white" strokeWidth="1.375" strokeLinejoin="round"/>
          <path d="M5.6875 15.563V27.938H10.1875V15.563H5.6875ZM13 15.563V27.938H17.5V21.541C17.5 20.313 18.625 18.063 21.8819 18.063C23.7303 18.063 24.8125 19.013 24.8125 20.875V27.938H29.3125V20.875C29.3125 19.402 28.9615 17.571 27.7443 16.063C26.4573 14.469 24.4671 13.563 21.883 13.563C20.1809 13.563 18.6936 14.254 17.5 15.099V15.563H13Z" stroke="white" strokeWidth="1.375" strokeLinejoin="round"/>
        </svg>
      </a>
    </div>
  );
}
