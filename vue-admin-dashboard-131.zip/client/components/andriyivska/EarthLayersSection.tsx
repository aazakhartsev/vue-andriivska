const layers = [
  "Пісок",
  "Глина",
  "Пісок з алевритом",
  "Крейда",
  "Глина блакитна",
  "Сеноманський водоносний горизонт",
];

export default function EarthLayersSection() {
  return (
    <section className="py-16 md:py-24 lg:py-32 px-4 md:px-8 lg:px-16 overflow-hidden">
      <div className="max-w-[1440px] mx-auto">
        {/* Title */}
        <div className="text-center mb-8 md:mb-12">
          <h2 className="font-rubik font-normal text-5xl sm:text-6xl md:text-7xl lg:text-[80px] leading-[90%] tracking-[-4px] mb-4">
            <span className="text-white">Шлях крізь </span>
            <span className="text-[#FF7A2A]">землю</span>
          </h2>
          <p className="text-white font-rubik text-lg md:text-2xl leading-[90%] tracking-tight mt-6 max-w-xl mx-auto">
            Вода проходить природну фільтрацію через кілька геологічних шарів
          </p>
        </div>

        {/* Earth cross-section */}
        <div className="relative flex flex-col lg:flex-row items-center gap-8 lg:gap-12">
          {/* Earth image with orange glow */}
          <div className="relative flex-shrink-0 w-full max-w-[500px] lg:max-w-[600px] mx-auto lg:mx-0">
            {/* Orange glow */}
            <div
              className="absolute inset-0 rounded-full"
              style={{
                background: 'rgba(255, 122, 42, 0.90)',
                filter: 'blur(160px)',
                transform: 'scale(0.7)',
              }}
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/e7f909b1c3e878d0313bd254c861f51baa137ed3?width=1824"
              alt="Шари землі"
              className="relative z-10 w-full h-auto"
            />

            {/* Info cards overlaid */}
            <div className="absolute z-20 left-0 top-1/4 flex flex-col gap-4">
              <InfoCard
                icon={
                  <svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 47H47M7.05 0H39.95M2.35 35.2794L2.3735 35.2471M44.6735 35.2794L44.65 35.2471M4.7 23.5294L4.7235 23.4971M42.3235 23.5294L42.3 23.4971M7.05 11.7794L7.0735 11.7471M39.9735 11.7794L39.95 11.7471M23.5 8.8125V38.1875M23.5 8.8125L19.975 13.2188M23.5 8.8125L27.025 13.2188M23.5 38.1875L16.45 29.375M23.5 38.1875L30.55 29.375" stroke="white" strokeWidth="2.08" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                }
                value="48м"
                label="глибина артезіанської свердловини"
              />
              <InfoCard
                icon={
                  <svg width="44" height="47" viewBox="0 0 44 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M36.9286 16.2692C36.9286 27.1154 21.8215 39.7692 21.8215 39.7692C21.8215 39.7692 6.71436 27.1154 6.71436 16.2692C6.71436 7.40792 13.5931 0 21.8215 0C30.0499 0 36.9286 7.40792 36.9286 16.2692Z" stroke="white" strokeWidth="2.08" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M35.5085 34.3462H38.6071L43.6429 47H0L5.03571 34.3462H8.13436M21.8214 21.6923C23.157 21.6923 24.4378 21.121 25.3822 20.104C26.3266 19.0869 26.8571 17.7076 26.8571 16.2693C26.8571 14.831 26.3266 13.4516 25.3822 12.4346C24.4378 11.4175 23.157 10.8462 21.8214 10.8462C20.4859 10.8462 19.205 11.4175 18.2606 12.4346C17.3163 13.4516 16.7857 14.831 16.7857 16.2693C16.7857 17.7076 17.3163 19.0869 18.2606 20.104C19.205 21.121 20.4859 21.6923 21.8214 21.6923Z" stroke="white" strokeWidth="2.08" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                }
                value="Київ"
                label={'біля парку "Нивки"'}
              />
            </div>
          </div>

          {/* Layers list */}
          <div className="flex-1 w-full">
            <div className="space-y-4 md:space-y-6">
              {layers.map((layer, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="flex items-center gap-2 flex-1">
                    <div className="w-3 h-3 rounded-sm bg-white flex-shrink-0" />
                    <div className="flex-1 h-px bg-white/40" />
                  </div>
                  <span className="text-white font-rubik text-xl md:text-2xl lg:text-[36px] leading-[90%] tracking-[-1.8px] whitespace-nowrap">
                    {layer}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function InfoCard({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-[39px] px-5 py-4 flex flex-col items-center text-center gap-1 min-w-[150px]">
      <div className="mb-1">{icon}</div>
      <div className="text-white font-rubik text-3xl md:text-4xl font-normal leading-none tracking-[-2.8px]">
        {value}
      </div>
      <div className="text-white font-rubik text-sm leading-tight tracking-tight">
        {label}
      </div>
    </div>
  );
}
