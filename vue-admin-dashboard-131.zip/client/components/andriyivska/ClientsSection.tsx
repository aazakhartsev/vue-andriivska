const clients = [
  {
    name: "Артем",
    logo: "https://api.builder.io/api/v1/image/assets/TEMP/6cc63af94aa13acb0ba1523e62e24c66ba5205f0?width=684",
    width: "w-48 md:w-60",
  },
  {
    name: "Winner",
    logo: "https://api.builder.io/api/v1/image/assets/TEMP/24b28a3d80b8f51cf6b88bc76697296832f2c4c2?width=684",
    width: "w-48 md:w-60",
  },
  {
    name: "ПТФС",
    logo: "https://api.builder.io/api/v1/image/assets/TEMP/974d41f684c43c7e34bb501b7a698a322a9e6432?width=709",
    width: "w-48 md:w-60",
  },
  {
    name: "Стоунлайт",
    logo: "https://api.builder.io/api/v1/image/assets/TEMP/7f04f7ffcad2a616aaaaf308cacaf224b29940e3?width=557",
    width: "w-32 md:w-48",
  },
];

export default function ClientsSection() {
  return (
    <section className="py-16 md:py-24 px-4 md:px-8 lg:px-16">
      <div className="max-w-[1440px] mx-auto">
        {/* Title */}
        <div className="text-center mb-12 md:mb-16">
          <h2 className="font-rubik font-normal text-4xl sm:text-5xl md:text-6xl lg:text-[80px] leading-[104%] tracking-[-4px]">
            <span className="text-white">Наші </span>
            <span className="text-[#FF7A2A]">клієнти</span>
          </h2>
        </div>

        {/* Client logos */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {clients.map((client) => (
            <div
              key={client.name}
              className="bg-white/20 rounded-[40px] md:rounded-[92px] flex items-center justify-center p-6 md:p-10 aspect-video md:aspect-square"
            >
              <img
                src={client.logo}
                alt={client.name}
                className={`${client.width} h-auto object-contain`}
              />
            </div>
          ))}
        </div>

        {/* Navigation arrows */}
        <div className="flex justify-between items-center mt-6 md:hidden">
          <button className="w-14 h-14 rounded-[17px] bg-white/20 flex items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 70 70" fill="none">
              <path d="M37.8945 28.5318L32.1057 35.4998L37.8945 41.5566" stroke="white" strokeWidth="1.92961"/>
            </svg>
          </button>
          <button className="w-14 h-14 rounded-[17px] bg-white/20 flex items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 70 70" fill="none">
              <path d="M33.8828 28.5318L39.6716 35.4998L33.8828 41.5566" stroke="white" strokeWidth="1.92961"/>
            </svg>
          </button>
        </div>
      </div>
    </section>
  );
}
