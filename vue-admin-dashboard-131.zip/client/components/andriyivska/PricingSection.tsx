export default function PricingSection() {
  return (
    <section className="py-16 md:py-24 px-4 md:px-8 lg:px-16" id="pricing">
      <div className="max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6 mb-8 md:mb-12">
          {/* 100 грн - TOP SELLER */}
          <div className="relative bg-white/20 rounded-[60px] md:rounded-[100px] overflow-hidden p-6 md:p-8 flex flex-col items-center text-center">
            {/* TOP badge */}
            <div className="absolute top-0 right-0">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/ddd8cfdedaf103c6977702dcb2ca966db40054ff?width=494"
                alt="Топ продажів"
                className="w-20 md:w-28 h-auto rounded-tl-none rounded-tr-[100px] rounded-br-none rounded-bl-none"
              />
              <div className="absolute top-4 right-2 transform rotate-45 text-center">
                <div className="text-white font-rubik font-normal text-xl md:text-2xl leading-tight">ТОП</div>
                <div className="text-white font-rubik font-normal text-xs leading-tight">продажів</div>
              </div>
            </div>

            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/6eb52d3afe059b8be719679250cb57a55d1a3a4f?width=772"
              alt="Бутиль"
              className="w-40 h-40 md:w-56 md:h-56 object-contain my-4 md:my-6"
              style={{ boxShadow: '-7px -11px 9.3px 0 rgba(0,0,0,0.25) inset, 9px 10px 14.1px 0 rgba(0,0,0,0.25)' }}
            />
            <p className="text-white font-rubik text-sm md:text-base leading-[90%] tracking-tight mb-2 min-h-[48px] flex items-center">
              Якщо Ви підключені до нашої мережі, або у Вашому будинку стоїть наша стійка
            </p>
            <div className="text-white font-rubik font-normal text-4xl md:text-6xl lg:text-[80px] leading-[90%] tracking-[-4px] mt-auto">
              100 грн
            </div>
          </div>

          {/* 150 грн */}
          <div className="bg-white/20 rounded-[60px] md:rounded-[100px] p-6 md:p-8 flex flex-col items-center text-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/6f15150e57650c15a9137cde6da3767b1ab1a110?width=772"
              alt="Бутиль"
              className="w-40 h-40 md:w-56 md:h-56 object-contain my-4 md:my-6"
              style={{ boxShadow: '-7px -11px 9.3px 0 rgba(0,0,0,0.25) inset, 9px 10px 14.1px 0 rgba(0,0,0,0.25)' }}
            />
            <p className="text-white font-rubik text-sm md:text-base leading-[90%] tracking-tight mb-2 min-h-[48px] flex items-center">
              Якщо Ви не підключені до нашої мережі
            </p>
            <div className="text-white font-rubik font-normal mt-auto">
              <span className="text-3xl md:text-4xl">від</span>
              <span className="text-4xl md:text-6xl lg:text-[80px] leading-[90%] tracking-[-4px]"> 150 грн</span>
            </div>
          </div>

          {/* 250 грн */}
          <div className="bg-white/20 rounded-[60px] md:rounded-[100px] p-6 md:p-8 flex flex-col items-center text-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/e4302e9a8389a6e3ec171adecd19c15f3fb48da4?width=772"
              alt="Private label"
              className="w-40 h-40 md:w-56 md:h-56 object-contain my-4 md:my-6"
              style={{ boxShadow: '-7px -11px 9.3px 0 rgba(0,0,0,0.25) inset, 9px 10px 14.1px 0 rgba(0,0,0,0.25)' }}
            />
            <p className="text-white font-rubik text-sm md:text-base leading-[90%] tracking-tight mb-2 min-h-[48px] flex items-center">
              Private label та доставка у чітко визначений час
            </p>
            <div className="text-white font-rubik font-normal text-4xl md:text-6xl lg:text-[80px] leading-[90%] tracking-[-4px] mt-auto">
              250 грн
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <p className="text-white font-rubik text-sm md:text-base lg:text-xl tracking-tight leading-normal mb-8 md:mb-10 max-w-4xl">
          Вартість води вказана з урахуванням доставки до квартири чи офісу без вартості бутля, який станом на 04.04.2026 складає 350 грн.<br />
          Вартість бутля не сплачується, якщо клієнт надає свій бутиль.<br />
          Заставна вартість повертається клієнту за першою вимогою при поверненні бутля.
        </p>

        {/* Order button */}
        <div className="flex justify-center">
          <button className="bg-[#FF7A2A] hover:bg-[#e66a1a] transition-colors text-black font-rubik font-normal text-xl md:text-2xl tracking-tight px-16 md:px-24 py-5 md:py-7 rounded-[30px] w-full max-w-[533px]">
            Замовити
          </button>
        </div>
      </div>
    </section>
  );
}
