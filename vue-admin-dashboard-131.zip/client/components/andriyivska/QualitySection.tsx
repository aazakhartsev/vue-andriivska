const qualityItems = [
  {
    title: "Полікарбонатний бутель",
    description: "Полікарбонат добре зберігає чистоту і не взаємодіє з водою — хімічно нейтральний матеріал, схвалений для харчового використання.",
  },
  {
    title: "Поліетиленовий захисний пакет",
    description: "Кожен бутель загорнутий у пакет, що захищає від зовнішніх забруднень та сонячних променів під час зберігання та доставки.",
  },
  {
    title: "Миття чистою водою + пара 60°C",
    description: "Перед кожним наповненням бутель ретельно промивається та обробляється гарячою парою — надійна гігієнічна підготовка без хімії.",
  },
  {
    title: "Герметичне пломбування",
    description: "Після наповнення бутель пломбується, що гарантує незайманість води до моменту відкриття у вас вдома.",
  },
];

export default function QualitySection() {
  return (
    <section className="py-16 md:py-24 lg:py-32 px-4 md:px-8 lg:px-16">
      <div className="max-w-[1440px] mx-auto">
        {/* Title */}
        <div className="text-center mb-12 md:mb-20">
          <h2 className="font-rubik font-normal text-4xl sm:text-5xl md:text-6xl lg:text-[80px] leading-[104%] tracking-[-4px]">
            <span className="text-white">Захист </span>
            <span className="text-[#FF7A2A]">якості</span>
          </h2>
        </div>

        <div className="flex flex-col lg:flex-row gap-10 lg:gap-16 items-center">
          {/* Quality list */}
          <div className="flex-1 space-y-8 md:space-y-12">
            {qualityItems.map((item, i) => (
              <div key={i} className="flex gap-4 md:gap-6">
                <div className="flex-shrink-0 w-4 h-5 md:w-5 md:h-6 rounded bg-white mt-1" />
                <div>
                  <h3 className="text-[#FF7A2A] font-rubik font-normal text-xl md:text-3xl lg:text-5xl leading-tight tracking-tight mb-2">
                    {item.title}
                  </h3>
                  <p className="text-white font-rubik font-normal text-sm md:text-base lg:text-xl leading-normal tracking-tight">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Water shield image */}
          <div className="flex-shrink-0 relative w-full max-w-[500px] lg:max-w-[600px] mx-auto lg:mx-0">
            {/* Orange glow */}
            <div
              className="absolute inset-0 rounded-full"
              style={{
                background: '#FF7A2A',
                filter: 'blur(175px)',
                opacity: 0.6,
              }}
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/4677d89c631909479346ff60df6cab2cde3cd5e1?width=1864"
              alt="Щит води"
              className="relative z-10 w-full h-auto"
            />
            {/* Bubble decorations */}
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/ed92f5cbd2759f564fb05976fd5c6f4d1db6d946?width=316"
              alt=""
              className="absolute z-20 bottom-10 left-1/3 w-12 h-auto opacity-80"
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/5e3d66246f374db27f4be029170b717932bba984?width=220"
              alt=""
              className="absolute z-20 top-0 right-1/4 w-8 h-auto opacity-80"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
