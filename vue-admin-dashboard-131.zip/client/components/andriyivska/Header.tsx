import { useState } from "react";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 px-4 md:px-8 lg:px-12 py-4 md:py-6">
      <div className="max-w-[1920px] mx-auto flex items-center justify-between gap-4">
        {/* Logo */}
        <a href="#" className="flex-shrink-0">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/64a48292dd05693323002855f49c3eec35e918a3?width=268"
            alt="Андріївська"
            className="h-12 md:h-16 lg:h-[87px] w-auto"
          />
        </a>

        {/* Nav Links - Desktop */}
        <nav className="hidden md:flex items-center gap-2 lg:gap-3">
          <NavLink href="#about" active>Про нас</NavLink>
          <NavLink href="#pricing">Ціни</NavLink>
          <NavLink href="#partners">Партнерам</NavLink>
        </nav>

        {/* Right side */}
        <div className="hidden md:flex items-center gap-3">
          {/* Phone */}
          <a
            href="tel:+380634908000"
            className="flex items-center justify-center px-4 py-2 rounded-[30px] bg-white/10 text-white font-rubik text-base lg:text-xl tracking-tight hover:bg-white/20 transition-colors whitespace-nowrap"
          >
            +38 (063) 490 8000
          </a>
          {/* Language */}
          <button className="flex items-center justify-center px-4 py-2 rounded-[57px] bg-white/10 font-rubik text-base lg:text-xl uppercase tracking-tight">
            <span className="text-white">uk</span>
            <span className="text-white/50 mx-1">|</span>
            <span className="text-white/50">en</span>
          </button>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          <span className={`block w-6 h-0.5 bg-white transition-transform ${mobileMenuOpen ? 'rotate-45 translate-y-2' : ''}`} />
          <span className={`block w-6 h-0.5 bg-white transition-opacity ${mobileMenuOpen ? 'opacity-0' : ''}`} />
          <span className={`block w-6 h-0.5 bg-white transition-transform ${mobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden mt-4 bg-brand-blue-dark/95 backdrop-blur-sm rounded-2xl p-6 flex flex-col gap-4">
          <a href="#about" className="text-white font-rubik text-lg uppercase tracking-tight" onClick={() => setMobileMenuOpen(false)}>Про нас</a>
          <a href="#pricing" className="text-white font-rubik text-lg uppercase tracking-tight" onClick={() => setMobileMenuOpen(false)}>Ціни</a>
          <a href="#partners" className="text-white font-rubik text-lg uppercase tracking-tight" onClick={() => setMobileMenuOpen(false)}>Партнерам</a>
          <a href="tel:+380634908000" className="flex items-center justify-center px-4 py-2 rounded-[30px] bg-white/10 text-white font-rubik text-base">
            +38 (063) 490 8000
          </a>
        </div>
      )}
    </header>
  );
}

function NavLink({ href, children, active }: { href: string; children: React.ReactNode; active?: boolean }) {
  return (
    <a
      href={href}
      className={`flex items-center justify-center px-6 py-2 rounded-full border border-white font-rubik text-sm lg:text-base text-white uppercase tracking-tight transition-colors hover:bg-white/20 ${
        active ? 'bg-brand-blue-dark' : 'bg-white/10'
      }`}
    >
      {children}
    </a>
  );
}
