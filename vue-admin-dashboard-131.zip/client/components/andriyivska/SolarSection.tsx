export default function SolarSection() {
  return (
    <section className="py-16 md:py-24 lg:py-32 px-4 md:px-8 lg:px-16">
      <div className="max-w-[1440px] mx-auto">
        {/* Title */}
        <div className="text-center mb-12 md:mb-20">
          <h2 className="font-rubik font-normal text-4xl sm:text-5xl md:text-6xl lg:text-[80px] leading-[90%] tracking-[-4px]">
            <span className="text-white">Вода, що працює<br />на </span>
            <span className="text-[#FF7A2A]">сонці</span>
          </h2>
        </div>

        {/* Two cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
          {/* Solar panels card */}
          <div className="bg-white/20 rounded-[60px] md:rounded-[100px] p-6 md:p-8 lg:p-10 relative overflow-hidden">
            {/* Icon */}
            <div className="mb-4">
              <svg width="155" height="155" viewBox="0 0 155 155" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-20">
                <path d="M77.4998 142.083C113.168 142.083 142.083 113.168 142.083 77.4998C142.083 41.8314 113.168 12.9165 77.4998 12.9165C41.8314 12.9165 12.9165 41.8314 12.9165 77.4998C12.9165 113.168 41.8314 142.083 77.4998 142.083Z" stroke="white" strokeOpacity="0.2" strokeWidth="6"/>
                <path d="M52.4995 74.9034L78.3263 40.093C80.3478 37.3676 84.1324 39.0596 84.1324 42.6892V69.6334C84.1324 71.8034 85.6178 73.5665 87.452 73.5665H100.007C102.862 73.5665 104.386 77.5578 102.5 80.0959L76.673 114.906C74.6516 117.632 70.867 115.94 70.867 112.31V85.3659C70.867 83.1959 69.3816 81.4328 67.5474 81.4328H54.9924C52.1443 81.4328 50.6201 77.4415 52.5059 74.9034" stroke="white" strokeOpacity="0.2" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>

            {/* Solar panels image */}
            <div className="relative mb-6">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/4f27f2298a28412eae68a51e885f01b09b7c0031?width=1443"
                alt="Сонячні панелі"
                className="w-full h-[200px] md:h-[280px] object-cover rounded-2xl"
                style={{ boxShadow: '11px 30px 35.8px 0 rgba(0,0,0,0.74)' }}
              />
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f357df38d1f56a962c585d18bda1a644a50de439?width=618"
                alt="Акумулятор"
                className="absolute right-4 bottom-4 w-28 md:w-36 h-auto rounded-xl"
                style={{ boxShadow: '16px 32px 38.5px 0 rgba(0,0,0,0.74)' }}
              />
            </div>

            <h3 className="text-white font-rubik font-normal text-2xl md:text-3xl lg:text-[50px] leading-[90%] tracking-[-2.5px]">
              На <span className="text-[#FF7A2A]">100%</span> самі забезпечуємо себе{" "}
              <span className="text-[#FF7A2A]">електроенергією</span>
            </h3>
          </div>

          {/* Electric car card */}
          <div className="bg-white/20 rounded-[60px] md:rounded-[100px] p-6 md:p-8 lg:p-10 relative overflow-hidden">
            {/* Icon */}
            <div className="mb-4">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/c1c19f57468be9a86b46c13593fdd31c93302339?width=274"
                alt="Електро авто"
                className="w-16 h-16 md:w-20 md:h-20 object-contain"
              />
            </div>

            {/* Electric car image */}
            <div className="relative mb-6">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/a059206bbaaf80b3fdc908700ceefb0b3046935f?width=1698"
                alt="Електро авто Андріївська"
                className="w-full h-[200px] md:h-[280px] object-cover rounded-2xl"
              />
            </div>

            <h3 className="text-white font-rubik font-normal text-2xl md:text-3xl lg:text-[50px] leading-[90%] tracking-[-2.5px]">
              Доставляємо виключно{" "}
              <span className="text-[#FF7A2A]">електротранспортом</span>
            </h3>
          </div>
        </div>

        {/* Bottom text */}
        <div className="text-center mt-12 md:mt-20">
          <h2 className="font-rubik font-normal text-3xl sm:text-4xl md:text-5xl lg:text-[80px] leading-[90%] tracking-[-4px]">
            <span className="text-white">Це дозволяє нам </span>
            <span className="text-[#FF7A2A]">тримати</span>
            <span className="text-white"> найкращу </span>
            <span className="text-[#FF7A2A]">ціну</span>
            <span className="text-white"> в Україні</span>
          </h2>
        </div>
      </div>
    </section>
  );
}
