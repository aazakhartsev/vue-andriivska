export default function Footer() {
  return (
    <footer className="relative overflow-hidden">
      {/* Wave background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[#02438A]" />
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1920 261"
          fill="none"
          preserveAspectRatio="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M336.186 22.8558C1092.6 81.606 1738.03 -50.5608 2288.97 22.8558C2839.91 96.2723 2307.47 161.003 2288.97 217.433C2270.48 273.863 336.186 234.881 336.186 234.881C336.186 234.881 -420.233 -35.8945 336.186 22.8558Z"
            fill="#002C5C"
          />
        </svg>
      </div>

      <div className="relative z-10 px-4 md:px-8 lg:px-16 py-12 md:py-16">
        <div className="max-w-[1440px] mx-auto">
          <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-8">
            {/* Logo */}
            <a href="#" className="flex-shrink-0">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/64a48292dd05693323002855f49c3eec35e918a3?width=268"
                alt="Андріївська"
                className="h-14 md:h-20 w-auto"
              />
            </a>

            {/* Nav links */}
            <div className="flex flex-col md:flex-row items-center gap-4 md:gap-16">
              <a href="#about" className="text-white font-rubik text-lg md:text-xl leading-[90%] tracking-tight hover:text-[#FF7A2A] transition-colors">
                Про нас
              </a>
              <a href="#pricing" className="text-white font-rubik text-lg md:text-xl leading-[90%] tracking-tight hover:text-[#FF7A2A] transition-colors">
                Ціни
              </a>
              <a href="#partners" className="text-white font-rubik text-lg md:text-xl leading-[90%] tracking-tight hover:text-[#FF7A2A] transition-colors">
                Партнерам
              </a>
            </div>

            {/* Contact & Social */}
            <div className="flex flex-col items-center md:items-end gap-4">
              {/* Phone */}
              <a
                href="tel:+380634908000"
                className="flex items-center justify-center px-5 py-2.5 rounded-[30px] bg-white/10 text-white font-rubik text-base md:text-lg tracking-tight hover:bg-white/20 transition-colors"
              >
                +38 (063) 490 8000
              </a>

              {/* Social icons */}
              <div className="flex items-center gap-3">
                {/* Instagram */}
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
                  <svg width="20" height="20" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" clipRule="evenodd" d="M35.1347 18.304C31.0576 17.8518 26.9431 17.8518 22.866 18.304C20.5187 18.5665 18.6228 20.4156 18.3475 22.7746C17.8646 26.91 17.8646 31.0876 18.3475 35.223C18.6228 37.582 20.5175 39.4311 22.866 39.6936C26.9431 40.1449 31.0576 40.1449 35.1347 39.6936C37.482 39.4311 39.3778 37.582 39.6532 35.223C40.1361 31.0876 40.1361 26.91 39.6532 22.7746C39.3778 20.4156 37.4832 18.5665 35.1347 18.304ZM23.0597 20.0423C27.008 19.6045 30.9927 19.6045 34.941 20.0423C36.4927 20.2173 37.7352 21.4411 37.916 22.9788C38.384 26.9785 38.384 31.0191 37.916 35.0188C37.8225 35.7714 37.478 36.4704 36.9382 37.003C36.3983 37.5356 35.6947 37.8707 34.941 37.9541C30.9927 38.392 27.008 38.392 23.0597 37.9541C22.3059 37.8707 21.6023 37.5356 21.0625 37.003C20.5227 36.4704 20.1782 35.7714 20.0847 35.0188C19.6167 31.0191 19.6167 26.9785 20.0847 22.9788C20.1782 22.2263 20.5227 21.5272 21.0625 20.9946C21.6023 20.462 22.3059 20.1257 23.0597 20.0423Z" fill="white"/>
                    <circle cx="29" cy="28" r="4.5" stroke="white" strokeWidth="1.5"/>
                    <circle cx="34.833" cy="23.167" r="1" fill="white"/>
                  </svg>
                </a>
                {/* Facebook */}
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
                  <svg width="20" height="20" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22 12H18.7273C17.2806 12 15.8933 12.5795 14.8703 13.611C13.8474 14.6424 13.2727 16.0414 13.2727 17.5V20.8H10V25.2H13.2727V34H17.6364V25.2H20.9091L22 20.8H17.6364V17.5C17.6364 17.2083 17.7513 16.9285 17.9559 16.7222C18.1605 16.5159 18.4379 16.4 18.7273 16.4H22V12Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </a>
                {/* LinkedIn */}
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
                  <svg width="20" height="20" viewBox="0 0 59 59" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M17.6875 27.938V40.313H22.1875V27.938M17.6875 21.938C17.6875 22.534 17.9246 23.107 18.3465 23.529C18.7685 23.95 19.3408 24.188 19.9375 24.188C20.5342 24.188 21.1065 23.95 21.5285 23.529C21.9504 23.107 22.1875 22.534 22.1875 21.938C22.1875 21.341 21.9504 20.769 21.5285 20.347C21.1065 19.925 20.5342 19.688 19.9375 19.688C19.3408 19.688 18.7685 19.925 18.3465 20.347C17.9246 20.769 17.6875 21.341 17.6875 21.938ZM25 27.938V40.313H29.5V34.541C29.5 33.313 30.625 31.063 33.8819 31.063C35.7303 31.063 36.8125 32.013 36.8125 33.875V40.313H41.3125V33.875C41.3125 32.402 40.9615 30.571 39.7443 29.063C38.4573 27.469 36.4671 26.563 33.883 26.563C32.1809 26.563 30.6936 27.254 29.5 28.099V27.938H25Z" stroke="white" strokeWidth="1.375" strokeLinejoin="round"/>
                  </svg>
                </a>
              </div>
            </div>
          </div>

          {/* Copyright */}
          <div className="mt-8 md:mt-12 text-center">
            <p className="text-white font-rubik text-sm md:text-base leading-[90%] tracking-tight">
              Андріївська © 2026. Всі права захищені.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
