const steps = [
  "Формування документу",
  "Відправка у Вчасно, M.E.Doc, WhatsApp, Telegram, Viber, e-mail",
  "Підписання документу за допомогою ЕЦП",
];

export default function DocumentSection() {
  return (
    <section className="py-16 md:py-24 px-4 md:px-8 lg:px-16">
      <div className="max-w-[1440px] mx-auto">
        {/* Title */}
        <div className="text-center mb-4">
          <h2 className="font-rubik font-normal text-3xl sm:text-4xl md:text-5xl lg:text-[80px] leading-[90%] tracking-[-4px]">
            <span className="text-white">Цифровий </span>
            <span className="text-[#FF7A2A]">комфорт:</span>
            <span className="text-[#FF7A2A]"> Заощаджуйте час </span>
            <span className="text-white">на папері</span>
          </h2>
          <p className="text-white font-rubik text-base md:text-xl lg:text-2xl tracking-tight leading-[104%] mt-6 max-w-2xl mx-auto">
            Ми використовуємо тільки електронний документообіг.<br />
            Більше ніяких паперів та очікування кур'єра.
          </p>
        </div>

        {/* Document flow visual */}
        <div className="relative mt-12 md:mt-16 overflow-hidden rounded-[40px] md:rounded-[60px] bg-white/10 p-6 md:p-8">
          {/* Orange glow */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse at center, rgba(255,122,42,0.4) 0%, transparent 70%)',
            }}
          />

          {/* Bubbles */}
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/dc041c43cd76a923023bdaee48cfe03a59e6b105?width=230"
            alt=""
            className="absolute right-1/4 top-0 w-10 md:w-16 h-auto opacity-70 z-10"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/baff9f5c2ad87eaef8720cfebc64a87497285c4b?width=230"
            alt=""
            className="absolute left-0 top-1/4 w-10 md:w-16 h-auto opacity-70 z-10"
          />

          {/* Document flow image */}
          <div className="relative z-10">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/1f1a0eb0d63f9c202b745d2f2c70f35c49b01aff?width=2600"
              alt="Документооборот"
              className="w-full h-auto rounded-xl"
            />
            {/* Messenger overlay */}
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/7d144cabbe9806123f0a57620198ce27a1e733f1?width=712"
              alt="Месенджери"
              className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-40 md:w-64 h-auto"
            />
          </div>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mt-10 md:mt-12">
          {steps.map((step, i) => (
            <div key={i} className="text-center">
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-[#FF7A2A] text-black font-rubik font-semibold text-lg flex items-center justify-center mx-auto mb-3">
                {i + 1}
              </div>
              <p className="text-white font-rubik font-normal text-base md:text-xl lg:text-2xl leading-[104%] tracking-tight">
                {step}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
