export default function CertificatesSection() {
  return (
    <section className="py-16 md:py-24 px-4 md:px-8 lg:px-16">
      <div className="max-w-[1440px] mx-auto">
        {/* Title */}
        <div className="text-center mb-12 md:mb-16">
          <h2 className="font-rubik font-normal text-4xl sm:text-5xl md:text-6xl lg:text-[80px] leading-[104%] tracking-[-4px]">
            <span className="text-white">Підтвердження </span>
            <span className="text-[#FF7A2A]">якості</span>
          </h2>
        </div>

        {/* Certificate display */}
        <div className="relative flex justify-center">
          {/* Orange glow */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse at center, rgba(255,122,42,0.5) 0%, transparent 65%)',
              filter: 'blur(30px)',
            }}
          />

          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/c09d62dbc9e8edc754e6d94f215f2c5775d1a50a?width=1044"
            alt="Сертифікат відповідності"
            className="relative z-10 w-full max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg h-auto shadow-2xl rounded-2xl"
          />
        </div>
      </div>
    </section>
  );
}
