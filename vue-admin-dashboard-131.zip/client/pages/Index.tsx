import Header from "@/components/andriyivska/Header";
import HeroSection from "@/components/andriyivska/HeroSection";
import EarthLayersSection from "@/components/andriyivska/EarthLayersSection";
import WaterAnalysisSection from "@/components/andriyivska/WaterAnalysisSection";
import SolarSection from "@/components/andriyivska/SolarSection";
import PricingSection from "@/components/andriyivska/PricingSection";
import QualitySection from "@/components/andriyivska/QualitySection";
import DocumentSection from "@/components/andriyivska/DocumentSection";
import CertificatesSection from "@/components/andriyivska/CertificatesSection";
import ClientsSection from "@/components/andriyivska/ClientsSection";
import PartnerSection from "@/components/andriyivska/PartnerSection";
import Footer from "@/components/andriyivska/Footer";
import SocialSidebar from "@/components/andriyivska/SocialSidebar";

export default function Index() {
  return (
    <div className="min-h-screen brand-gradient font-rubik">
      <Header />
      <SocialSidebar />
      <main>
        <HeroSection />
        <EarthLayersSection />
        <WaterAnalysisSection />
        <SolarSection />
        <PricingSection />
        <QualitySection />
        <DocumentSection />
        <CertificatesSection />
        <ClientsSection />
        <PartnerSection />
      </main>
      <Footer />
    </div>
  );
}
