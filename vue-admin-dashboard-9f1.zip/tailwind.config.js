/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        orange: '#FF7A2A',
        'blue-deep': '#033873',
        'blue-primary': '#086AD4',
        'blue-dark': '#002C5C',
      },
      fontFamily: {
        rubik: ['Rubik', 'sans-serif'],
        alexandria: ['Alexandria', 'sans-serif'],
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(162deg, #033873 0.55%, #086AD4 99.39%)',
      },
    },
  },
  plugins: [],
}
