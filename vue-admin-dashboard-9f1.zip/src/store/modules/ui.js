export default {
  namespaced: true,
  state: () => ({
    mobileMenuOpen: false,
    currentLang: 'uk',
    navScrolled: false,
  }),
  mutations: {
    SET_MENU_OPEN(state, val) {
      state.mobileMenuOpen = val
    },
    SET_LANG(state, lang) {
      state.currentLang = lang
    },
    SET_NAV_SCROLLED(state, val) {
      state.navScrolled = val
    },
  },
  actions: {
    toggleMenu({ commit, state }) {
      commit('SET_MENU_OPEN', !state.mobileMenuOpen)
    },
    closeMenu({ commit }) {
      commit('SET_MENU_OPEN', false)
    },
    setNavScrolled({ commit }, val) {
      commit('SET_NAV_SCROLLED', val)
    },
    switchLang({ commit }, lang) {
      commit('SET_LANG', lang)
    },
  },
  getters: {
    mobileMenuOpen: (s) => s.mobileMenuOpen,
    currentLang: (s) => s.currentLang,
    navScrolled: (s) => s.navScrolled,
  },
}
