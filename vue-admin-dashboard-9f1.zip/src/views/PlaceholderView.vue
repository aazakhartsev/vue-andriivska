<template>
  <div class="placeholder">
    <div class="placeholder__content">
      <div class="placeholder__icon">
        <svg width="80" height="80" viewBox="0 0 155 155" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M77.4998 142.083C113.168 142.083 142.083 113.168 142.083 77.4998C142.083 41.8314 113.168 12.9165 77.4998 12.9165C41.8314 12.9165 12.9165 41.8314 12.9165 77.4998C12.9165 113.168 41.8314 142.083 77.4998 142.083Z" stroke="white" stroke-opacity="0.4" stroke-width="6"/>
          <path d="M52.4995 74.9034L78.3263 40.093C80.3478 37.3676 84.1324 39.0596 84.1324 42.6892V69.6334C84.1324 71.8034 85.6178 73.5665 87.452 73.5665H100.007C102.862 73.5665 104.386 77.5578 102.5 80.0959L76.673 114.906C74.6516 117.632 70.867 115.94 70.867 112.31V85.3659C70.867 83.1959 69.3816 81.4328 67.5474 81.4328H54.9924C52.1443 81.4328 50.6201 77.4415 52.5059 74.9034" stroke="white" stroke-opacity="0.4" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>

      <h1 class="placeholder__title">{{ pageTitle }}</h1>
      <p class="placeholder__text">Цей розділ знаходиться у розробці. Продовжуйте натискати підказки, щоб заповнити цю сторінку.</p>

      <router-link to="/" class="placeholder__btn">← Повернутися на головну</router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PlaceholderView',
  computed: {
    pageTitle() {
      return this.$route.meta?.title || 'Сторінка'
    },
  },
}
</script>

<style lang="scss" scoped>
.placeholder {
  min-height: 80vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
  padding-top: 120px;

  &__content {
    max-width: 600px;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 24px;
  }

  &__icon {
    opacity: 0.5;
  }

  &__title {
    font-size: clamp(32px, 5vw, 64px);
    font-weight: 400;
    color: #fff;
    letter-spacing: -3px;
    line-height: 1;
  }

  &__text {
    font-size: clamp(16px, 1.8vw, 22px);
    color: rgba(255, 255, 255, 0.7);
    letter-spacing: -0.8px;
    line-height: 1.5;
  }

  &__btn {
    display: inline-flex;
    align-items: center;
    padding: 14px 32px;
    border-radius: 30px;
    background: rgba(255, 255, 255, 0.10);
    color: #fff;
    font-size: 18px;
    letter-spacing: -0.9px;
    text-decoration: none;
    transition: background 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.18);
    }
  }
}
</style>
