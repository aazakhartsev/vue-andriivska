<template>
  <div class="home">

    <!-- HERO SECTION -->
    <section class="hero">
      <div class="hero__image-wrap">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/a0762713f278d236dbd14862755dda3fe6cb673e?width=4216"
          alt="Андріївська вулиця, Київ"
          class="hero__image"
        />
        <div class="hero__overlay"></div>
      </div>

      <!-- Social sidebar -->
      <div class="hero__social">
        <a href="#" class="hero__social-btn" aria-label="Instagram">
          <svg width="24" height="24" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M35.1347 18.304C31.0576 17.8518 26.9431 17.8518 22.866 18.304C20.5187 18.5665 18.6228 20.4156 18.3475 22.7746C17.8646 26.91 17.8646 31.0876 18.3475 35.223C18.6228 37.582 20.5175 39.4311 22.866 39.6936C26.9431 40.1449 31.0576 40.1449 35.1347 39.6936C37.482 39.4311 39.3778 37.582 39.6532 35.223C40.1361 31.0876 40.1361 26.91 39.6532 22.7746C39.3778 20.4156 37.4832 18.5665 35.1347 18.304ZM28.9997 23.457C27.5299 23.457 26.1204 24.0409 25.0811 25.0801C24.0419 26.1194 23.458 27.529 23.458 28.9987C23.458 30.4684 24.0419 31.878 25.0811 32.9172C26.1204 33.9565 27.5299 34.5404 28.9997 34.5404C30.4694 34.5404 31.879 33.9565 32.9182 32.9172C33.9575 31.878 34.5413 30.4684 34.5413 28.9987C34.5413 27.529 33.9575 26.1194 32.9182 25.0801C31.879 24.0409 30.4694 23.457 28.9997 23.457Z" fill="white"/>
            <path d="M33.667 23.1667C33.667 22.8572 33.7899 22.5605 34.0087 22.3417C34.2275 22.1229 34.5242 22 34.8337 22C35.1431 22 35.4398 22.1229 35.6586 22.3417C35.8774 22.5605 36.0003 22.8572 36.0003 23.1667C36.0003 23.4761 35.8774 23.7728 35.6586 23.9916C35.4398 24.2104 35.1431 24.3333 34.8337 24.3333C34.5242 24.3333 34.2275 24.2104 34.0087 23.9916C33.7899 23.7728 33.667 23.4761 33.667 23.1667Z" fill="white"/>
          </svg>
        </a>
        <a href="#" class="hero__social-btn" aria-label="Facebook">
          <svg width="24" height="24" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 10H15.7273C14.2806 10 12.8933 10.5795 11.8703 11.611C10.8474 12.6424 10.2727 14.0414 10.2727 15.5V18.8H7V23.2H10.2727V32H14.6364V23.2H17.9091L19 18.8H14.6364V15.5C14.6364 15.2083 14.7513 14.9285 14.9559 14.7222C15.1605 14.5159 15.4379 14.4 15.7273 14.4H19V10Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </a>
        <a href="#" class="hero__social-btn" aria-label="LinkedIn">
          <svg width="24" height="24" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.6875 5.9375C1.6875 6.534 1.9246 7.107 2.3465 7.529C2.7685 7.951 3.3408 8.188 3.9375 8.188C4.5342 8.188 5.1065 7.951 5.5285 7.529C5.9504 7.107 6.1875 6.534 6.1875 5.9375C6.1875 5.341 5.9504 4.769 5.5285 4.347C5.1065 3.925 4.5342 3.688 3.9375 3.688C3.3408 3.688 2.7685 3.925 2.3465 4.347C1.9246 4.769 1.6875 5.341 1.6875 5.9375ZM1.6875 27.3125V11.5625H6.1875V27.3125H1.6875ZM9 11.5625V27.3125H13.5V19.541C13.5 18.313 14.625 16.063 17.8819 16.063C19.7303 16.063 20.8125 17.013 20.8125 18.875V27.3125H25.3125V18.875C25.3125 17.402 24.9615 15.571 23.7443 14.063C22.4573 12.469 20.4671 11.563 17.883 11.563C16.1809 11.563 14.6936 12.254 13.5 13.099V11.5625H9Z" stroke="white" stroke-width="1.375" stroke-linejoin="round"/>
          </svg>
        </a>
      </div>

      <!-- Hero tagline -->
      <div class="hero__tagline">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/9c3305582ab5bf491619e1620648ed4badb992a6?width=298"
          alt="Для щоденного споживання"
          class="hero__tagline-img"
        />
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/b5be25e8bcc509d9a6db2239f1e2622e40a7e15b?width=424"
          alt="Вона має м'який смак та унікальний склад мінералів"
          class="hero__tagline-sub"
        />
      </div>

      <!-- Hero product image -->
      <div class="hero__product">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/d66fc5de02f91dfd72f295db8901ac536f32b8f9?width=606"
          alt="Андріївська вода"
          class="hero__product-img"
        />
      </div>
    </section>

    <!-- FEATURE CARDS -->
    <section class="features">
      <div class="features__grid">
        <div class="features__card" v-for="card in featureCards" :key="card.id">
          <div class="features__card-icon" v-html="card.icon"></div>
          <h3 class="features__card-title">{{ card.title }}</h3>
          <p class="features__card-desc">{{ card.desc }}</p>
        </div>
      </div>
    </section>

    <!-- TASTE SECTION -->
    <section class="taste">
      <div class="taste__container">
        <h2 class="taste__heading">
          М'який <span class="taste__orange">смак</span> та унікальний мінеральний <span class="taste__orange">склад</span> для <span class="taste__orange">щоденного вживання</span>
        </h2>
      </div>
    </section>

    <!-- WATER ANALYSIS TABLE -->
    <section class="analysis">
      <div class="analysis__container">
        <div class="analysis__header">
          <div class="analysis__header-left">
            <h2 class="analysis__title">Аналіз води</h2>
            <a href="#" class="analysis__date">на дату 01.04.2026</a>
          </div>
          <svg class="analysis__calendar" width="50" height="50" viewBox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M52.4961 14.001H62.9961V66.501H6.99609V14.001H17.4961V10.501C17.4961 9.06598 18.0211 7.84098 19.0361 6.79098C20.0511 5.77598 21.3111 5.25098 22.7461 5.25098C24.1811 5.25098 25.4411 5.77598 26.4561 6.79098C27.4711 7.84098 27.9961 9.06598 27.9961 10.501V14.001H41.9961V10.501C41.9961 9.06598 42.5211 7.84098 43.5361 6.79098C44.5511 5.77598 45.8111 5.25098 47.2461 5.25098C48.6811 5.25098 49.9411 5.77598 50.9561 6.79098C51.9711 7.84098 52.4961 9.06598 52.4961 10.501V14.001ZM20.9961 10.501V19.251C20.9961 19.741 21.1711 20.161 21.5211 20.511C21.8361 20.826 22.2561 21.001 22.7461 21.001C23.2361 21.001 23.6561 20.826 23.9711 20.511C24.3211 20.161 24.4961 19.741 24.4961 19.251V10.501C24.4961 10.011 24.3211 9.59098 23.9711 9.27598C23.6561 8.92598 23.2361 8.75098 22.7461 8.75098C22.2561 8.75098 21.8361 8.92598 21.5211 9.27598C21.1711 9.59098 20.9961 10.011 20.9961 10.501ZM45.4961 10.501V19.251C45.4961 19.741 45.6711 20.161 45.9861 20.511C46.3361 20.826 46.7561 21.001 47.2461 21.001C47.7361 21.001 48.1561 20.826 48.5061 20.511C48.8211 20.161 48.9961 19.741 48.9961 19.251V10.501C48.9961 10.011 48.8211 9.59098 48.5061 9.27598C48.1561 8.92598 47.7361 8.75098 47.2461 8.75098C46.7561 8.75098 46.3361 8.92598 45.9861 9.27598C45.6711 9.59098 45.4961 10.011 45.4961 10.501ZM59.4961 63.001V28.001H10.4961V63.001H59.4961Z" fill="#FF7A2A"/>
          </svg>
        </div>

        <div class="analysis__table-wrap">
          <table class="analysis__table">
            <thead>
              <tr>
                <th>Показник</th>
                <th>Нормативне значення</th>
                <th>Фактичне значення води «Андріївська»</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="row in analysisRows" :key="row.indicator">
                <td>{{ row.indicator }}</td>
                <td>{{ row.norm }}</td>
                <td>{{ row.actual }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="analysis__footer">
          <a href="#" class="analysis__full-link">Повний аналіз води</a>
        </div>
      </div>
    </section>

    <!-- GEOLOGICAL SECTION -->
    <section class="geo">
      <div class="geo__container">
        <div class="geo__heading-block">
          <h2 class="geo__title">
            Шлях крізь <span class="geo__orange">землю</span>
          </h2>
          <p class="geo__subtitle">Вода проходить природну фільтрацію через кілька геологічних шарів</p>
        </div>

        <div class="geo__content">
          <div class="geo__image-block">
            <div class="geo__glow"></div>
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/e7f909b1c3e878d0313bd254c861f51baa137ed3?width=1824"
              alt="Шари землі"
              class="geo__image"
            />
            <div class="geo__badges">
              <div class="geo__badge">
                <svg width="36" height="36" viewBox="0 0 47 47" fill="none">
                  <path d="M0 47H47M7.05 0H39.95M23.5 8.8125V38.1875M23.5 8.8125L19.975 13.2188M23.5 8.8125L27.025 13.2188M23.5 38.1875L16.45 29.375M23.5 38.1875L30.55 29.375" stroke="white" stroke-width="2.08" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <div class="geo__badge-value">48м</div>
                <div class="geo__badge-label">глибина артезіанської свердловини</div>
              </div>
              <div class="geo__badge">
                <svg width="36" height="42" viewBox="0 0 44 47" fill="none">
                  <path d="M36.9286 16.2692C36.9286 27.1154 21.8215 39.7692 21.8215 39.7692C21.8215 39.7692 6.71436 27.1154 6.71436 16.2692C6.71436 7.40792 13.5931 0 21.8215 0C30.0499 0 36.9286 7.40792 36.9286 16.2692Z" stroke="white" stroke-width="2.08" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M35.5085 34.3462H38.6071L43.6429 47H0L5.03571 34.3462H8.13436M21.8214 21.6923C23.157 21.6923 24.4378 21.121 25.3822 20.104C26.3266 19.0869 26.8571 17.7076 26.8571 16.2693C26.8571 14.831 26.3266 13.4516 25.3822 12.4346C24.4378 11.4175 23.157 10.8462 21.8214 10.8462C20.4859 10.8462 19.205 11.4175 18.2606 12.4346C17.3163 13.4516 16.7857 14.831 16.7857 16.2693C16.7857 17.7076 17.3163 19.0869 18.2606 20.104C19.205 21.121 20.4859 21.6923 21.8214 21.6923Z" stroke="white" stroke-width="2.08" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <div class="geo__badge-value">Київ</div>
                <div class="geo__badge-label">біля парку "Нивки"</div>
              </div>
            </div>
          </div>

          <div class="geo__layers">
            <div class="geo__layer" v-for="layer in geoLayers" :key="layer.name">
              <div class="geo__layer-dot"></div>
              <span class="geo__layer-name">{{ layer.name }}</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- SOLAR SECTION -->
    <section class="solar">
      <div class="solar__container">
        <h2 class="solar__title">
          Вода, що працює на <span class="solar__orange">сонці</span>
        </h2>

        <div class="solar__cards">
          <!-- Solar panels card -->
          <div class="solar__card">
            <div class="solar__card-images">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/4f27f2298a28412eae68a51e885f01b09b7c0031?width=1443"
                alt="Сонячні панелі"
                class="solar__card-img solar__card-img--panels"
              />
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f357df38d1f56a962c585d18bda1a644a50de439?width=618"
                alt="Акумулятор"
                class="solar__card-img solar__card-img--battery"
              />
            </div>
            <div class="solar__card-icon-wrap">
              <svg width="80" height="80" viewBox="0 0 155 155" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M77.4998 142.083C113.168 142.083 142.083 113.168 142.083 77.4998C142.083 41.8314 113.168 12.9165 77.4998 12.9165C41.8314 12.9165 12.9165 41.8314 12.9165 77.4998C12.9165 113.168 41.8314 142.083 77.4998 142.083Z" stroke="white" stroke-opacity="0.3" stroke-width="6"/>
                <path d="M52.4995 74.9034L78.3263 40.093C80.3478 37.3676 84.1324 39.0596 84.1324 42.6892V69.6334C84.1324 71.8034 85.6178 73.5665 87.452 73.5665H100.007C102.862 73.5665 104.386 77.5578 102.5 80.0959L76.673 114.906C74.6516 117.632 70.867 115.94 70.867 112.31V85.3659C70.867 83.1959 69.3816 81.4328 67.5474 81.4328H54.9924C52.1443 81.4328 50.6201 77.4415 52.5059 74.9034" stroke="white" stroke-opacity="0.3" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <p class="solar__card-caption">
              На <span class="solar__orange">100%</span> самі забезпечуємо себе <span class="solar__orange">електроенергією</span>
            </p>
          </div>

          <!-- Cross divider -->
          <div class="solar__cross">
            <svg width="52" height="60" viewBox="0 0 52 60" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M27 0L27 60" stroke="white" stroke-opacity="0.3" stroke-width="8" stroke-linecap="round"/>
              <path d="M52 31L0 31" stroke="white" stroke-opacity="0.3" stroke-width="8" stroke-linecap="round"/>
            </svg>
          </div>

          <!-- EV card -->
          <div class="solar__card">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/c1c19f57468be9a86b46c13593fdd31c93302339?width=274"
              alt="Електромобіль"
              class="solar__card-icon-img"
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/a059206bbaaf80b3fdc908700ceefb0b3046935f?width=1698"
              alt="Електро авто Андріївська"
              class="solar__card-img solar__card-img--car"
            />
            <p class="solar__card-caption">
              Доставляємо виключно <span class="solar__orange">електротранспортом</span>
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- PRICE INTRO -->
    <section class="price-intro">
      <div class="price-intro__container">
        <h2 class="price-intro__heading">
          Це дозволяє нам <span class="price-intro__orange">тримати</span> найкращу <span class="price-intro__orange">ціну</span> в Україні
        </h2>
      </div>
    </section>

    <!-- PRICING SECTION -->
    <section class="pricing" id="tsiny">
      <div class="pricing__container">
        <div class="pricing__cards">
          <!-- 100 грн card -->
          <div class="pricing__card">
            <div class="pricing__badge">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/ddd8cfdedaf103c6977702dcb2ca966db40054ff?width=494"
                alt="ТОП продажів"
                class="pricing__badge-img"
              />
            </div>
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/6eb52d3afe059b8be719679250cb57a55d1a3a4f?width=772"
              alt="Бутиль Андріївська"
              class="pricing__bottle"
            />
            <p class="pricing__desc">Якщо Ви підключені до нашої мережі, або у Вашому будинку стоїть наша стійка</p>
            <div class="pricing__price">100 грн</div>
          </div>

          <!-- 150 грн card -->
          <div class="pricing__card">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/6f15150e57650c15a9137cde6da3767b1ab1a110?width=772"
              alt="Бутиль Андріївська"
              class="pricing__bottle"
            />
            <p class="pricing__desc">Якщо Ви не підключені до нашої мережі</p>
            <div class="pricing__price">від 150 грн</div>
          </div>

          <!-- 250 грн card -->
          <div class="pricing__card">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/e4302e9a8389a6e3ec171adecd19c15f3fb48da4?width=772"
              alt="Private Label"
              class="pricing__bottle"
            />
            <p class="pricing__desc">Private label та доставка у чітко визначений час</p>
            <div class="pricing__price">250 грн</div>
          </div>
        </div>

        <p class="pricing__note">
          Вартість води вказана з урахуванням доставки до квартири чи офісу без вартості бутля, який станом на 04.04.2026 складає 350 грн.
          Вартість бутля не сплачується, якщо клієнт надає свій бутиль.
          Заставна вартість повертається клієнту за першою вимогою при поверненні бутля.
        </p>

        <div class="pricing__cta">
          <a href="tel:+380634908000" class="pricing__btn">Замовити</a>
        </div>
      </div>
    </section>

    <!-- QUALITY SECTION -->
    <section class="quality">
      <div class="quality__container">
        <div class="quality__glow"></div>
        <h2 class="quality__title">
          Захист <span class="quality__orange">якості</span>
        </h2>

        <div class="quality__content">
          <div class="quality__list">
            <div class="quality__item" v-for="item in qualityItems" :key="item.title">
              <div class="quality__item-dot"></div>
              <div class="quality__item-text">
                <h3 class="quality__item-title">{{ item.title }}</h3>
                <p class="quality__item-desc">{{ item.desc }}</p>
              </div>
            </div>
          </div>

          <div class="quality__image-block">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/ed92f5cbd2759f564fb05976fd5c6f4d1db6d946?width=316"
              alt=""
              class="quality__bubble quality__bubble--1"
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/5e3d66246f374db27f4be029170b717932bba984?width=220"
              alt=""
              class="quality__bubble quality__bubble--2"
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/4677d89c631909479346ff60df6cab2cde3cd5e1?width=1864"
              alt="Захист якості - бутель"
              class="quality__shield"
            />
          </div>
        </div>
      </div>
    </section>

    <!-- CERTIFICATES SECTION -->
    <section class="certs">
      <div class="certs__container">
        <div class="certs__glow"></div>
        <h2 class="certs__title">
          Підтвердження <span class="certs__orange">якості</span>
        </h2>
        <div class="certs__image-wrap">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/c09d62dbc9e8edc754e6d94f215f2c5775d1a50a?width=1044"
            alt="Сертифікат відповідності"
            class="certs__image"
          />
        </div>
      </div>
    </section>

    <!-- DIGITAL DOCUMENTS SECTION -->
    <section class="docs">
      <div class="docs__container">
        <div class="docs__glow"></div>
        <h2 class="docs__title">
          Цифровий <span class="docs__orange">комфорт:</span> <span class="docs__orange">Заощаджуйте час</span> на папері
        </h2>
        <p class="docs__subtitle">
          Ми використовуємо тільки електронний документообіг.<br>
          Більше ніяких паперів та очікування кур'єра.
        </p>

        <div class="docs__flow">
          <div class="docs__step">Формування документу</div>
          <div class="docs__arrow">→</div>
          <div class="docs__step">Відправка у Вчасно, M.E.Doc, WhatsApp, Telegram, Viber, e-mail</div>
          <div class="docs__arrow">→</div>
          <div class="docs__step">Підписання документу за допомогою ЕЦП</div>
        </div>

        <div class="docs__images">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/dc041c43cd76a923023bdaee48cfe03a59e6b105?width=230"
            alt=""
            class="docs__bubble docs__bubble--left"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/1f1a0eb0d63f9c202b745d2f2c70f35c49b01aff?width=2600"
            alt="Документообіг"
            class="docs__main-img"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/7d144cabbe9806123f0a57620198ce27a1e733f1?width=712"
            alt="Месенджери"
            class="docs__messengers"
          />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/954eb5df41f4557dd342321549f1f19bab9c1635?width=162"
            alt=""
            class="docs__bubble docs__bubble--right"
          />
        </div>
      </div>
    </section>

    <!-- CLIENTS SECTION -->
    <section class="clients">
      <div class="clients__container">
        <h2 class="clients__title">
          Наші <span class="clients__orange">клієнти</span>
        </h2>
        <div class="clients__grid">
          <div class="clients__logo-card" v-for="client in clients" :key="client.name">
            <img :src="client.logo" :alt="client.name" class="clients__logo" />
          </div>
        </div>
      </div>
    </section>

    <!-- PARTNER NETWORK -->
    <section class="partners">
      <div class="partners__container">
        <h2 class="partners__title">
          <span class="partners__orange">Партнерська</span> мережа
        </h2>

        <div class="partners__content">
          <!-- Left: Stand + program info -->
          <div class="partners__left">
            <div class="partners__stand-block">
              <div class="partners__glow"></div>
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f695e9152b573323f71e2390cff716cefc5ce310?width=230"
                alt=""
                class="partners__bubble partners__bubble--right"
              />
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/50b08673f0b68f058cb6cccb9fcc9e66dc121e3f?width=230"
                alt=""
                class="partners__bubble partners__bubble--left"
              />
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/0222148f695a66d51b96992c98f8fdf28caecbec?width=1228"
                alt="Стійка з бутлями"
                class="partners__stand-img"
              />
            </div>

            <div class="partners__program">
              <p class="partners__question">Маєте бізнес-центр, ОСББ чи будинок з охороною?</p>
              <p class="partners__install">Встановлюйте наші стійки з бутлями</p>
              <div class="partners__earn">
                <p class="partners__earn-text">отримуйте</p>
                <p class="partners__earn-pct">10%</p>
                <p class="partners__earn-text">від продажів</p>
              </div>
            </div>
          </div>

          <!-- Right: Form -->
          <div class="partners__form-block">
            <form class="partners__form" @submit.prevent="submitPartnerForm">
              <div class="partners__field">
                <input
                  v-model="partnerForm.name"
                  type="text"
                  placeholder="Імʼя *"
                  class="partners__input"
                  required
                />
              </div>
              <div class="partners__field">
                <input
                  v-model="partnerForm.phone"
                  type="tel"
                  placeholder="+380 (__) ___ __ __ *"
                  class="partners__input"
                  required
                />
              </div>
              <button type="submit" class="partners__submit">Стати партнером</button>
            </form>
          </div>
        </div>
      </div>
    </section>

  </div>
</template>

<script>
export default {
  name: 'HomeView',

  data() {
    return {
      partnerForm: {
        name: '',
        phone: '',
      },
      featureCards: [
        {
          id: 1,
          icon: `<svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M35.7247 14.5198C38.1734 16.9516 39.8449 20.0559 40.527 23.4389C41.209 26.822 40.8711 30.3314 39.5559 33.5221C38.2408 36.7128 36.0077 39.441 33.1399 41.3609C30.272 43.2807 26.8987 44.3056 23.4475 44.3056C19.9964 44.3056 16.623 43.2807 13.7552 41.3609C10.8874 39.441 8.65427 36.7128 7.33912 33.5221C6.02398 30.3314 5.68602 26.822 6.36811 23.4389C7.0502 20.0559 8.72162 16.9516 11.1704 14.5198L23.447 2.64374L35.7247 14.5198Z" stroke="white" stroke-width="2.08333" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M29.1562 21.3988C30.2946 22.5296 31.0716 23.973 31.3887 25.5459C31.7057 27.1189 31.5485 28.7505 30.937 30.234C30.3254 31.7175 29.2871 32.986 27.9537 33.8785C26.6203 34.7711 25.0519 35.2476 23.4473 35.2476C21.8427 35.2476 20.2743 34.7711 18.9409 33.8785C17.6075 32.986 16.5691 31.7175 15.9576 30.234C15.3461 28.7505 15.1889 27.1189 15.5059 25.5459C15.8229 23.973 16.5999 22.5296 17.7384 21.3988L23.4478 15.8763L29.1562 21.3988Z" stroke="white" stroke-width="2.08333" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>`,
          title: 'Ультрачиста вода',
          desc: 'збагачена всіма необхідними мінералами',
        },
        {
          id: 2,
          icon: `<svg width="47" height="47" viewBox="0 0 47 47" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M25.5198 11.2604L15.1357 26.2299L22.4198 26.0106L21.4798 35.7396L31.8638 20.7701L24.5798 20.9894L25.5198 11.2604Z" stroke="white" stroke-width="2.08333" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M23.4998 44.5521C35.1266 44.5521 44.5519 35.1268 44.5519 23.5C44.5519 11.8733 35.1266 2.44794 23.4998 2.44794C11.8731 2.44794 2.44775 11.8733 2.44775 23.5C2.44775 35.1268 11.8731 44.5521 23.4998 44.5521Z" stroke="white" stroke-width="2.08333" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>`,
          title: 'Іноваційна логістика',
          desc: 'доставка виключно електротранспортом',
        },
        {
          id: 3,
          icon: `<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.9971 33.433C29.2095 33.433 33.4351 29.2075 33.4351 23.995C33.4351 18.7825 29.2095 14.557 23.9971 14.557C18.7846 14.557 14.5591 18.7825 14.5591 23.995C14.5591 29.2075 18.7846 33.433 23.9971 33.433Z" stroke="white" stroke-width="2.08333" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2.5 23.995H9.846M23.997 45.5V38.15M23.997 9.85V2.5M38.154 23.995H45.5M8.79 39.192L13.985 33.998M39.2 39.2L34.002 34.002M13.989 13.991L8.79 8.794M34.002 13.984L39.196 8.79" stroke="white" stroke-width="2.08333" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>`,
          title: 'Енергія сонця',
          desc: '100% забезпечення себе електроенергією',
        },
      ],
      analysisRows: [
        { indicator: 'pH (кислотність)', norm: '6.5 - 8.5', actual: '8.3' },
        { indicator: 'Мінералізація, мг/дм³', norm: 'Не нормується', actual: '72.5' },
        { indicator: 'Жорсткість, ммоль/дм³', norm: '4.5', actual: '4.5' },
        { indicator: 'Кальцій (Ca²⁺), мг/дм³', norm: '25 - 75', actual: '4.01' },
        { indicator: 'Магній (Mg²⁺), мг/дм³', norm: '10 - 50', actual: '7.9' },
        { indicator: 'Сірководень та розчинені сульфіди', norm: 'не нормується', actual: 'не виявлено' },
        { indicator: 'Амоній (NH₄⁺), мг/дм³', norm: 'не більше 0.5', actual: 'менше 0.003' },
        { indicator: 'Нітрити, мг/дм³', norm: 'не більше 0.5', actual: 'менше 0.003' },
        { indicator: 'Нітрати, мг/дм³', norm: 'не більше 50', actual: '0.78' },
        { indicator: 'Хлориди, мг/дм³', norm: 'не більше 250', actual: 'менше 5' },
        { indicator: 'Сульфати, мг/дм³', norm: 'не більше 250', actual: 'менше 2' },
        { indicator: 'Залізо, мг/дм³', norm: 'не більше 0.2', actual: 'менше 0.05' },
        { indicator: 'Марганець, мг/дм³', norm: 'не більше 0.5', actual: 'менше 0.005' },
      ],
      geoLayers: [
        { name: 'Пісок' },
        { name: 'Глина' },
        { name: 'Пісок з алевритом' },
        { name: 'Крейда' },
        { name: 'Глина блакитна' },
        { name: 'Сеноманський водоносний горизонт' },
      ],
      qualityItems: [
        {
          title: 'Полікарбонатний бутель',
          desc: 'Полікарбонат добре зберігає чистоту і не взаємодіє з водою — хімічно нейтральний матеріал, схвалений для харчового використання.',
        },
        {
          title: 'Поліетиленовий захисний пакет',
          desc: 'Кожен бутель загорнутий у пакет, що захищає від зовнішніх забруднень та сонячних променів під час зберігання та доставки.',
        },
        {
          title: 'Миття чистою водою + пара 60°C',
          desc: 'Перед кожним наповненням бутель ретельно промивається та обробляється гарячою парою — надійна гігієнічна підготовка без хімії.',
        },
        {
          title: 'Герметичне пломбування',
          desc: 'Після наповнення бутель пломбується, що гарантує незайманість води до моменту відкриття у вас вдома.',
        },
      ],
      clients: [
        {
          name: 'Артем',
          logo: 'https://api.builder.io/api/v1/image/assets/TEMP/6cc63af94aa13acb0ba1523e62e24c66ba5205f0?width=684',
        },
        {
          name: 'Winner',
          logo: 'https://api.builder.io/api/v1/image/assets/TEMP/24b28a3d80b8f51cf6b88bc76697296832f2c4c2?width=684',
        },
        {
          name: 'ПФТС',
          logo: 'https://api.builder.io/api/v1/image/assets/TEMP/974d41f684c43c7e34bb501b7a698a322a9e6432?width=709',
        },
        {
          name: 'Стоунлайт',
          logo: 'https://api.builder.io/api/v1/image/assets/TEMP/7f04f7ffcad2a616aaaaf308cacaf224b29940e3?width=557',
        },
      ],
    }
  },

  methods: {
    submitPartnerForm() {
      alert(`Дякуємо, ${this.partnerForm.name}! Ми зв'яжемося з вами найближчим часом.`)
      this.partnerForm = { name: '', phone: '' }
    },
  },
}
</script>

<style lang="scss" scoped>
$orange: #FF7A2A;
$blue-dark: #002C5C;
$blue-deep: #033873;
$blue-primary: #086AD4;
$glass: rgba(217, 217, 217, 0.20);
$section-px: clamp(20px, 5vw, 80px);

// =====================
// HERO
// =====================
.hero {
  position: relative;
  overflow: hidden;
  min-height: 100svh;

  &__image-wrap {
    position: relative;
    width: 100%;
    height: 100svh;
    min-height: 500px;
    max-height: 900px;
    overflow: hidden;
  }

  &__image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center top;
    display: block;
  }

  &__overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(
      to bottom,
      rgba(3, 56, 115, 0.1) 0%,
      rgba(3, 56, 115, 0.4) 70%,
      rgba(3, 56, 115, 0.85) 100%
    );
  }

  &__social {
    position: absolute;
    left: clamp(15px, 2.5vw, 45px);
    top: 50%;
    transform: translateY(-50%);
    display: flex;
    flex-direction: column;
    gap: 16px;
    z-index: 10;

    @media (max-width: 600px) {
      display: none;
    }
  }

  &__social-btn {
    width: 54px;
    height: 54px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.10);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.20);
    }
  }

  &__tagline {
    position: absolute;
    top: clamp(150px, 20vh, 280px);
    right: clamp(20px, 5vw, 80px);
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 12px;
    z-index: 10;

    @media (max-width: 768px) {
      display: none;
    }
  }

  &__tagline-img {
    max-width: 220px;
    height: auto;
  }

  &__tagline-sub {
    max-width: 280px;
    height: auto;
  }

  &__product {
    position: absolute;
    bottom: clamp(10px, 5vh, 60px);
    left: clamp(60px, 10vw, 180px);
    z-index: 10;

    @media (max-width: 768px) {
      display: none;
    }
  }

  &__product-img {
    width: clamp(160px, 20vw, 280px);
    height: auto;
  }
}

// =====================
// FEATURES
// =====================
.features {
  padding: clamp(40px, 6vw, 80px) $section-px;

  &__grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: clamp(16px, 2vw, 32px);
    max-width: 1200px;
    margin: 0 auto;

    @media (max-width: 768px) {
      grid-template-columns: 1fr;
      max-width: 400px;
    }
  }

  &__card {
    background: $glass;
    border-radius: 40px;
    padding: clamp(24px, 3vw, 40px) clamp(20px, 2.5vw, 32px);
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    gap: 14px;
    transition: background 0.2s;

    &:hover {
      background: rgba(217, 217, 217, 0.28);
    }
  }

  &__card-icon {
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0.9;
  }

  &__card-title {
    font-size: clamp(18px, 2vw, 24px);
    font-weight: 400;
    color: $orange;
    letter-spacing: -1.68px;
    line-height: 1;
  }

  &__card-desc {
    font-size: clamp(14px, 1.4vw, 18px);
    color: #fff;
    letter-spacing: -1.26px;
    line-height: 1.3;
  }
}

// =====================
// TASTE
// =====================
.taste {
  padding: clamp(50px, 7vw, 100px) $section-px;

  &__container {
    max-width: 1100px;
    margin: 0 auto;
    text-align: center;
  }

  &__heading {
    font-size: clamp(32px, 5.5vw, 80px);
    font-weight: 400;
    line-height: 0.9;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    color: #fff;
  }

  &__orange {
    color: $orange;
  }
}

// =====================
// ANALYSIS TABLE
// =====================
.analysis {
  padding: clamp(40px, 5vw, 80px) $section-px;

  &__container {
    max-width: 1400px;
    margin: 0 auto;
    background: $glass;
    border-radius: clamp(30px, 4vw, 72px);
    padding: clamp(24px, 3vw, 50px);
  }

  &__header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 40px;
    gap: 20px;

    &-left {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
  }

  &__title {
    font-size: clamp(28px, 3.5vw, 50px);
    font-weight: 400;
    color: #fff;
    letter-spacing: -2.5px;
    line-height: 0.9;
  }

  &__date {
    font-size: clamp(22px, 2.8vw, 46px);
    font-weight: 400;
    color: $orange;
    letter-spacing: -2.3px;
    text-decoration: underline;
    text-underline-offset: 4px;
  }

  &__calendar {
    flex-shrink: 0;
    opacity: 0.9;
  }

  &__table-wrap {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }

  &__table {
    width: 100%;
    border-collapse: collapse;
    font-family: 'Rubik', sans-serif;

    th {
      font-size: clamp(14px, 1.8vw, 28px);
      font-weight: 500;
      color: #fff;
      letter-spacing: -1.4px;
      padding: clamp(10px, 1.5vw, 20px) clamp(8px, 1.2vw, 16px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.3);
      text-align: left;
      white-space: nowrap;

      &:last-child {
        text-align: right;
      }
    }

    td {
      font-size: clamp(12px, 1.5vw, 24px);
      color: #fff;
      letter-spacing: clamp(-0.6px, -0.1vw, -1.2px);
      padding: clamp(8px, 1.2vw, 18px) clamp(8px, 1.2vw, 16px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.15);
      vertical-align: middle;

      &:last-child {
        text-align: right;
        font-weight: 500;
      }
    }

    tr:last-child td {
      border-bottom: none;
    }
  }

  &__footer {
    margin-top: 32px;
    text-align: right;
  }

  &__full-link {
    font-size: clamp(20px, 2.5vw, 40px);
    font-weight: 400;
    color: #fff;
    letter-spacing: -2px;
    text-decoration: underline;
    text-underline-offset: 4px;
    transition: color 0.2s;

    &:hover {
      color: $orange;
    }
  }
}

// =====================
// GEOLOGICAL
// =====================
.geo {
  padding: clamp(50px, 7vw, 100px) $section-px;
  overflow: hidden;

  &__container {
    max-width: 1400px;
    margin: 0 auto;
  }

  &__heading-block {
    text-align: center;
    margin-bottom: clamp(32px, 5vw, 60px);
  }

  &__title {
    font-size: clamp(36px, 5.5vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 0.9;
    margin-bottom: 16px;
  }

  &__orange {
    color: $orange;
  }

  &__subtitle {
    font-size: clamp(16px, 1.8vw, 24px);
    color: #fff;
    letter-spacing: -1.2px;
    opacity: 0.85;
    line-height: 0.9;
  }

  &__content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: clamp(24px, 4vw, 60px);
    align-items: center;

    @media (max-width: 768px) {
      grid-template-columns: 1fr;
    }
  }

  &__image-block {
    position: relative;
  }

  &__glow {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 80%;
    height: 80%;
    border-radius: 50%;
    background: rgba(255, 122, 42, 0.5);
    filter: blur(120px);
    pointer-events: none;
    z-index: 0;
  }

  &__image {
    position: relative;
    z-index: 1;
    width: 100%;
    height: auto;
    display: block;
  }

  &__badges {
    display: flex;
    gap: clamp(16px, 2vw, 30px);
    margin-top: clamp(16px, 2vw, 24px);
    justify-content: center;
    flex-wrap: wrap;
  }

  &__badge {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    text-align: center;

    svg {
      opacity: 0.85;
    }
  }

  &__badge-value {
    font-size: clamp(24px, 3vw, 40px);
    color: #fff;
    font-weight: 400;
    letter-spacing: -2.8px;
    line-height: 1;
  }

  &__badge-label {
    font-size: clamp(12px, 1.4vw, 20px);
    color: #fff;
    letter-spacing: -1px;
    line-height: 1.2;
    max-width: 150px;
    opacity: 0.85;
  }

  &__layers {
    display: flex;
    flex-direction: column;
    gap: clamp(16px, 2vw, 28px);
  }

  &__layer {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: clamp(10px, 1.2vw, 16px) clamp(14px, 1.8vw, 24px);
    border-left: 3px solid rgba(255, 255, 255, 0.4);
    background: rgba(255, 255, 255, 0.04);
    border-radius: 0 12px 12px 0;
    transition: border-color 0.2s, background 0.2s;

    &:hover {
      border-color: $orange;
      background: rgba(255, 122, 42, 0.08);
    }
  }

  &__layer-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #fff;
    flex-shrink: 0;
    opacity: 0.7;
  }

  &__layer-name {
    font-size: clamp(16px, 2vw, 36px);
    color: #fff;
    font-weight: 400;
    letter-spacing: -1.8px;
    line-height: 0.9;
  }
}

// =====================
// SOLAR
// =====================
.solar {
  padding: clamp(50px, 7vw, 100px) $section-px;

  &__container {
    max-width: 1400px;
    margin: 0 auto;
  }

  &__title {
    font-size: clamp(32px, 5.5vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 0.9;
    text-align: center;
    margin-bottom: clamp(40px, 5vw, 70px);
  }

  &__orange {
    color: $orange;
  }

  &__cards {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    gap: clamp(16px, 2vw, 32px);
    align-items: center;

    @media (max-width: 900px) {
      grid-template-columns: 1fr;
    }
  }

  &__cross {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;

    @media (max-width: 900px) {
      padding: 10px;
    }
  }

  &__card {
    background: $glass;
    border-radius: clamp(40px, 5vw, 100px);
    padding: clamp(24px, 3vw, 40px);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    gap: clamp(12px, 1.5vw, 20px);
  }

  &__card-images {
    position: relative;
    width: 100%;
    height: clamp(200px, 25vw, 360px);
    overflow: hidden;
  }

  &__card-img {
    width: 100%;
    height: auto;
    object-fit: cover;
    border-radius: 12px;

    &--panels {
      transform: rotate(-167.852deg) scale(0.8);
      box-shadow: 11px 30px 35.8px rgba(0, 0, 0, 0.74);
      position: absolute;
      top: 0;
      left: 0;
      width: 80%;
    }

    &--battery {
      position: absolute;
      right: 0;
      top: 20%;
      width: 42%;
      box-shadow: 16px 32px 38.5px rgba(0, 0, 0, 0.74);
    }

    &--car {
      width: 100%;
      height: auto;
      border-radius: 12px;
    }
  }

  &__card-icon-wrap {
    opacity: 0.25;
    position: absolute;
    top: 20px;
    left: 20px;
  }

  &__card-icon-img {
    width: clamp(60px, 8vw, 120px);
    height: auto;
    object-fit: contain;
  }

  &__card-caption {
    font-size: clamp(18px, 2.5vw, 50px);
    font-weight: 400;
    color: #fff;
    letter-spacing: -2.5px;
    line-height: 0.9;
    margin-top: auto;
  }
}

// =====================
// PRICE INTRO
// =====================
.price-intro {
  padding: clamp(40px, 6vw, 80px) $section-px;
  text-align: center;

  &__container {
    max-width: 1000px;
    margin: 0 auto;
  }

  &__heading {
    font-size: clamp(32px, 5.5vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 0.9;
  }

  &__orange {
    color: $orange;
  }
}

// =====================
// PRICING
// =====================
.pricing {
  padding: clamp(40px, 5vw, 70px) $section-px;

  &__container {
    max-width: 1600px;
    margin: 0 auto;
  }

  &__cards {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: clamp(16px, 2vw, 28px);
    margin-bottom: clamp(24px, 3vw, 40px);

    @media (max-width: 768px) {
      grid-template-columns: 1fr;
      max-width: 400px;
      margin-left: auto;
      margin-right: auto;
    }
  }

  &__card {
    background: $glass;
    border-radius: clamp(50px, 6vw, 100px);
    padding: clamp(16px, 2vw, 30px);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: clamp(12px, 1.5vw, 20px);
    position: relative;
    overflow: visible;
    transition: background 0.2s;

    &:hover {
      background: rgba(217, 217, 217, 0.28);
    }
  }

  &__badge {
    position: absolute;
    top: -20px;
    right: -10px;
    width: clamp(80px, 12vw, 180px);
    z-index: 10;
  }

  &__badge-img {
    width: 100%;
    height: auto;
  }

  &__bottle {
    width: clamp(140px, 18vw, 300px);
    height: clamp(140px, 18vw, 300px);
    object-fit: contain;
    box-shadow: -7px -11px 9.3px rgba(0, 0, 0, 0.25) inset, 9px 10px 14.1px rgba(0, 0, 0, 0.25);
    border-radius: 12px;
  }

  &__desc {
    font-size: clamp(14px, 1.5vw, 25px);
    color: #fff;
    letter-spacing: -1.25px;
    line-height: 0.9;
    text-align: center;
    flex: 1;
  }

  &__price {
    font-size: clamp(24px, 4vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 0.9;
    text-align: center;
  }

  &__note {
    font-size: clamp(13px, 1.4vw, 22px);
    color: #fff;
    letter-spacing: -1.1px;
    line-height: 1.4;
    opacity: 0.85;
    margin-bottom: clamp(24px, 3vw, 40px);
    max-width: 1400px;
  }

  &__cta {
    display: flex;
    justify-content: center;
  }

  &__btn {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: clamp(14px, 2vw, 26px) clamp(40px, 8vw, 120px);
    border-radius: 30px;
    background: $orange;
    color: #000;
    font-family: 'Rubik', sans-serif;
    font-size: clamp(18px, 2vw, 26px);
    letter-spacing: -1.3px;
    text-decoration: none;
    font-weight: 400;
    transition: opacity 0.2s, transform 0.2s;

    &:hover {
      opacity: 0.9;
      transform: translateY(-2px);
    }
  }
}

// =====================
// QUALITY
// =====================
.quality {
  padding: clamp(50px, 7vw, 100px) $section-px;
  position: relative;
  overflow: hidden;

  &__container {
    max-width: 1600px;
    margin: 0 auto;
    position: relative;
  }

  &__glow {
    position: absolute;
    top: 0;
    right: -20%;
    width: 60%;
    height: 100%;
    border-radius: 50%;
    background: rgba(255, 122, 42, 0.5);
    filter: blur(175px);
    pointer-events: none;
    z-index: 0;
  }

  &__title {
    font-size: clamp(36px, 5.5vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 1.04;
    text-align: center;
    margin-bottom: clamp(40px, 5vw, 70px);
    position: relative;
    z-index: 1;
  }

  &__orange {
    color: $orange;
  }

  &__content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: clamp(24px, 4vw, 60px);
    align-items: center;
    position: relative;
    z-index: 1;

    @media (max-width: 900px) {
      grid-template-columns: 1fr;
    }
  }

  &__list {
    display: flex;
    flex-direction: column;
    gap: clamp(20px, 3vw, 40px);
  }

  &__item {
    display: flex;
    gap: clamp(14px, 1.5vw, 24px);
    align-items: flex-start;
  }

  &__item-dot {
    width: 20px;
    height: 22px;
    background: #fff;
    border-radius: 4px;
    flex-shrink: 0;
    margin-top: 8px;
  }

  &__item-text {
    flex: 1;
  }

  &__item-title {
    font-size: clamp(22px, 3vw, 60px);
    font-weight: 400;
    color: $orange;
    letter-spacing: -2px;
    line-height: 1;
    margin-bottom: 8px;
  }

  &__item-desc {
    font-size: clamp(13px, 1.4vw, 25px);
    color: #fff;
    letter-spacing: -1.25px;
    line-height: 1.4;
  }

  &__image-block {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: clamp(300px, 40vw, 700px);
  }

  &__shield {
    width: 90%;
    height: auto;
    position: relative;
    z-index: 2;
  }

  &__bubble {
    position: absolute;
    z-index: 3;
    opacity: 0.8;

    &--1 {
      right: 0;
      bottom: 10%;
      width: clamp(50px, 8vw, 120px);
    }

    &--2 {
      right: 15%;
      top: 0;
      width: clamp(40px, 6vw, 100px);
    }
  }
}

// =====================
// CERTIFICATES
// =====================
.certs {
  padding: clamp(50px, 7vw, 100px) $section-px;
  position: relative;
  overflow: hidden;

  &__container {
    max-width: 1400px;
    margin: 0 auto;
    position: relative;
  }

  &__glow {
    position: absolute;
    top: 10%;
    left: 50%;
    transform: translateX(-50%);
    width: 80%;
    height: 60%;
    border-radius: 50%;
    background: rgba(255, 122, 42, 0.6);
    filter: blur(175px);
    pointer-events: none;
    z-index: 0;
  }

  &__title {
    font-size: clamp(36px, 5.5vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 1.04;
    text-align: center;
    margin-bottom: clamp(40px, 5vw, 70px);
    position: relative;
    z-index: 1;
  }

  &__orange {
    color: $orange;
  }

  &__image-wrap {
    display: flex;
    justify-content: center;
    position: relative;
    z-index: 1;
  }

  &__image {
    width: clamp(240px, 40vw, 522px);
    height: auto;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
    border-radius: 8px;
  }
}

// =====================
// DIGITAL DOCS
// =====================
.docs {
  padding: clamp(50px, 7vw, 100px) $section-px;
  position: relative;
  overflow: hidden;

  &__container {
    max-width: 1600px;
    margin: 0 auto;
    position: relative;
  }

  &__glow {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
    height: 50%;
    border-radius: 50%;
    background: rgba(255, 122, 42, 0.55);
    filter: blur(167px);
    pointer-events: none;
    z-index: 0;
  }

  &__title {
    font-size: clamp(30px, 5vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 0.9;
    text-align: center;
    margin-bottom: clamp(16px, 2vw, 30px);
    position: relative;
    z-index: 1;
  }

  &__orange {
    color: $orange;
  }

  &__subtitle {
    font-size: clamp(15px, 1.7vw, 24px);
    color: #fff;
    letter-spacing: -1.2px;
    line-height: 1.04;
    text-align: center;
    opacity: 0.85;
    margin-bottom: clamp(30px, 4vw, 60px);
    position: relative;
    z-index: 1;
  }

  &__flow {
    display: flex;
    align-items: flex-start;
    justify-content: center;
    gap: clamp(12px, 2vw, 30px);
    margin-bottom: clamp(30px, 4vw, 60px);
    position: relative;
    z-index: 1;
    flex-wrap: wrap;

    @media (max-width: 768px) {
      flex-direction: column;
      align-items: center;
    }
  }

  &__step {
    font-size: clamp(14px, 1.8vw, 28px);
    color: #fff;
    letter-spacing: -1.4px;
    text-align: center;
    max-width: clamp(150px, 20vw, 320px);
    line-height: 1.04;
    flex: 1;
    min-width: 120px;
  }

  &__arrow {
    font-size: clamp(20px, 2.5vw, 40px);
    color: $orange;
    line-height: 1.04;
    flex-shrink: 0;
    padding-top: 4px;

    @media (max-width: 768px) {
      transform: rotate(90deg);
    }
  }

  &__images {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: clamp(200px, 30vw, 500px);
    z-index: 1;
  }

  &__main-img {
    width: min(90%, 1100px);
    height: auto;
    position: relative;
    z-index: 2;
    border-radius: 12px;
  }

  &__messengers {
    position: absolute;
    width: clamp(120px, 18vw, 320px);
    height: auto;
    z-index: 3;
    top: 50%;
    left: 50%;
    transform: translate(-10%, -30%);
    border-radius: 12px;
  }

  &__bubble {
    position: absolute;
    opacity: 0.7;
    z-index: 4;

    &--left {
      left: 0;
      top: 10%;
      width: clamp(40px, 6vw, 100px);

      @media (max-width: 600px) {
        display: none;
      }
    }

    &--right {
      right: 0;
      bottom: 10%;
      width: clamp(30px, 5vw, 80px);

      @media (max-width: 600px) {
        display: none;
      }
    }
  }
}

// =====================
// CLIENTS
// =====================
.clients {
  padding: clamp(50px, 7vw, 100px) $section-px;

  &__container {
    max-width: 1600px;
    margin: 0 auto;
  }

  &__title {
    font-size: clamp(36px, 5.5vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 1.04;
    text-align: center;
    margin-bottom: clamp(40px, 5vw, 70px);
  }

  &__orange {
    color: $orange;
  }

  &__grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: clamp(12px, 2vw, 28px);

    @media (max-width: 900px) {
      grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 480px) {
      grid-template-columns: 1fr 1fr;
      gap: 10px;
    }
  }

  &__logo-card {
    background: $glass;
    border-radius: clamp(30px, 5vw, 92px);
    padding: clamp(20px, 2.5vw, 40px) clamp(16px, 2vw, 30px);
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: clamp(100px, 12vw, 200px);
    transition: background 0.2s;

    &:hover {
      background: rgba(217, 217, 217, 0.28);
    }
  }

  &__logo {
    max-width: 100%;
    max-height: clamp(60px, 8vw, 130px);
    object-fit: contain;
    filter: brightness(0) invert(1);
    opacity: 0.85;
  }
}

// =====================
// PARTNERS
// =====================
.partners {
  padding: clamp(50px, 7vw, 100px) $section-px;
  overflow: hidden;

  &__container {
    max-width: 1600px;
    margin: 0 auto;
  }

  &__title {
    font-size: clamp(36px, 5.5vw, 80px);
    font-weight: 400;
    color: #fff;
    letter-spacing: clamp(-2px, -0.3vw, -4px);
    line-height: 1.04;
    text-align: center;
    margin-bottom: clamp(40px, 5vw, 70px);
  }

  &__orange {
    color: $orange;
  }

  &__content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: clamp(24px, 4vw, 60px);
    align-items: center;

    @media (max-width: 900px) {
      grid-template-columns: 1fr;
    }
  }

  &__left {
    display: flex;
    flex-direction: column;
    gap: clamp(24px, 3vw, 40px);
  }

  &__stand-block {
    position: relative;
    display: flex;
    justify-content: center;
  }

  &__glow {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 90%;
    height: 90%;
    border-radius: 50%;
    background: rgba(255, 122, 42, 0.6);
    filter: blur(167px);
    pointer-events: none;
  }

  &__bubble {
    position: absolute;
    opacity: 0.75;
    z-index: 2;

    &--left {
      left: 0;
      top: 20%;
      width: clamp(40px, 7vw, 115px);
    }

    &--right {
      right: 0;
      bottom: 10%;
      width: clamp(40px, 7vw, 115px);
    }
  }

  &__stand-img {
    position: relative;
    z-index: 1;
    width: min(100%, 500px);
    height: auto;
  }

  &__program {
    display: flex;
    flex-direction: column;
    gap: clamp(10px, 1.5vw, 20px);
    text-align: center;
  }

  &__question {
    font-size: clamp(18px, 2.8vw, 50px);
    color: #fff;
    letter-spacing: -2.5px;
    line-height: 1.04;
  }

  &__install {
    font-size: clamp(18px, 2.8vw, 50px);
    color: #fff;
    letter-spacing: -2.5px;
    line-height: 1.04;
  }

  &__earn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
  }

  &__earn-text {
    font-size: clamp(18px, 2.5vw, 50px);
    color: #fff;
    letter-spacing: -2.5px;
    line-height: 0.9;
  }

  &__earn-pct {
    font-size: clamp(60px, 10vw, 120px);
    color: $orange;
    letter-spacing: -3px;
    line-height: 0.9;
    font-family: 'Georgia', serif;
  }

  &__form-block {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  &__form {
    background: $glass;
    border-radius: 30px;
    padding: clamp(24px, 3vw, 48px);
    width: 100%;
    max-width: 560px;
    display: flex;
    flex-direction: column;
    gap: clamp(14px, 1.8vw, 24px);
  }

  &__field {
    width: 100%;
  }

  &__input {
    width: 100%;
    padding: clamp(12px, 1.5vw, 16px) clamp(16px, 2vw, 24px);
    border-radius: 12px;
    background: #fff;
    border: none;
    outline: none;
    font-family: 'Rubik', sans-serif;
    font-size: clamp(16px, 1.5vw, 20px);
    color: #000;
    letter-spacing: -1px;
    transition: box-shadow 0.2s;

    &:focus {
      box-shadow: 0 0 0 3px rgba(255, 122, 42, 0.4);
    }

    &::placeholder {
      color: rgba(0, 0, 0, 0.4);
    }
  }

  &__submit {
    width: 100%;
    padding: clamp(12px, 1.5vw, 18px) clamp(16px, 2vw, 24px);
    border-radius: 30px;
    background: $orange;
    border: none;
    color: #000;
    font-family: 'Rubik', sans-serif;
    font-size: clamp(15px, 1.5vw, 18px);
    letter-spacing: -0.9px;
    cursor: pointer;
    transition: opacity 0.2s, transform 0.2s;
    margin-top: 8px;

    &:hover {
      opacity: 0.9;
      transform: translateY(-2px);
    }
  }
}

</style>
