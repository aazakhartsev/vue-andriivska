<template>
  <header :class="['navbar', { 'navbar--scrolled': scrolled, 'navbar--open': mobileMenuOpen }]">
    <div class="navbar__inner">
      <!-- Logo -->
      <router-link to="/" class="navbar__logo" @click="closeMenu">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/64a48292dd05693323002855f49c3eec35e918a3?width=268"
          alt="Андріївська"
          class="navbar__logo-img"
        />
      </router-link>

      <!-- Desktop nav -->
      <nav class="navbar__nav">
        <router-link to="/pro-nas" :class="['navbar__link', { 'navbar__link--active': $route.name === 'about' }]">
          Про нас
        </router-link>
        <router-link to="/tsiny" :class="['navbar__link', { 'navbar__link--active': $route.name === 'prices' }]">
          Ціни
        </router-link>
        <router-link to="/partnerams" :class="['navbar__link', { 'navbar__link--active': $route.name === 'partners' }]">
          Партнерам
        </router-link>
      </nav>

      <!-- Right side -->
      <div class="navbar__right">
        <a href="tel:+380634908000" class="navbar__phone">
          +38 (063) 490 8000
        </a>
        <button class="navbar__lang" @click="toggleLang">
          <span :class="{ 'navbar__lang--active': currentLang === 'uk' }">uk</span>
          <span class="navbar__lang-sep"> | </span>
          <span :class="{ 'navbar__lang--active': currentLang === 'en' }">en</span>
        </button>
        <!-- Burger -->
        <button class="navbar__burger" @click="toggleMenu" :aria-label="mobileMenuOpen ? 'Закрити меню' : 'Відкрити меню'">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </div>

    <!-- Mobile menu -->
    <div class="navbar__mobile" v-if="mobileMenuOpen">
      <router-link to="/pro-nas" class="navbar__mobile-link" @click="closeMenu">Про нас</router-link>
      <router-link to="/tsiny" class="navbar__mobile-link" @click="closeMenu">Ціни</router-link>
      <router-link to="/partnerams" class="navbar__mobile-link" @click="closeMenu">Партнерам</router-link>
      <a href="tel:+380634908000" class="navbar__mobile-link" @click="closeMenu">+38 (063) 490 8000</a>
    </div>
  </header>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
  name: 'AppNavbar',
  data() {
    return {
      scrolled: false,
    }
  },
  computed: {
    ...mapGetters('ui', ['mobileMenuOpen', 'currentLang']),
  },
  methods: {
    ...mapActions('ui', ['toggleMenu', 'closeMenu', 'switchLang']),
    toggleLang() {
      const next = this.currentLang === 'uk' ? 'en' : 'uk'
      this.switchLang(next)
    },
    handleScroll() {
      this.scrolled = window.scrollY > 50
    },
  },
  mounted() {
    window.addEventListener('scroll', this.handleScroll, { passive: true })
  },
  beforeUnmount() {
    window.removeEventListener('scroll', this.handleScroll)
  },
}
</script>

<style lang="scss" scoped>
$orange: #FF7A2A;
$blue-dark: #002C5C;
$glass: rgba(255, 255, 255, 0.10);

.navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  transition: background 0.3s ease, box-shadow 0.3s ease;
  padding: 12px 0;

  &--scrolled {
    background: rgba(3, 56, 115, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.3);
  }

  &__inner {
    max-width: 1920px;
    margin: 0 auto;
    padding: 0 45px;
    display: flex;
    align-items: center;
    gap: 20px;
  }

  &__logo {
    flex-shrink: 0;
    text-decoration: none;

    &-img {
      height: 60px;
      width: auto;
      display: block;
    }
  }

  &__nav {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0 auto;

    @media (max-width: 768px) {
      display: none;
    }
  }

  &__link {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 10px 20px;
    border-radius: 93px;
    border: 1px solid rgba(255, 255, 255, 0.5);
    background: $glass;
    color: #fff;
    font-family: 'Rubik', sans-serif;
    font-size: 16px;
    letter-spacing: -0.64px;
    text-transform: uppercase;
    text-decoration: none;
    transition: background 0.2s, border-color 0.2s;
    white-space: nowrap;

    &--active,
    &.router-link-active {
      background: $blue-dark;
      border-color: #fff;
    }

    &:hover:not(&--active):not(.router-link-active) {
      background: rgba(255, 255, 255, 0.15);
    }
  }

  &__right {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-shrink: 0;

    @media (max-width: 768px) {
      gap: 8px;
    }
  }

  &__phone {
    display: flex;
    align-items: center;
    padding: 10px 18px;
    border-radius: 30px;
    background: $glass;
    color: #fff;
    font-family: 'Rubik', sans-serif;
    font-size: 18px;
    letter-spacing: -1px;
    text-decoration: none;
    white-space: nowrap;
    transition: background 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.18);
    }

    @media (max-width: 900px) {
      display: none;
    }
  }

  &__lang {
    display: flex;
    align-items: center;
    padding: 10px 18px;
    border-radius: 30px;
    background: $glass;
    border: none;
    color: #fff;
    font-family: 'Rubik', sans-serif;
    font-size: 18px;
    letter-spacing: -1px;
    text-transform: uppercase;
    cursor: pointer;
    transition: background 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.18);
    }

    &-sep {
      color: rgba(255, 255, 255, 0.5);
      margin: 0 2px;
    }

    &--active {
      color: #fff;
    }

    span:not(&-sep):not(&--active) {
      color: rgba(127, 126, 126, 1);
    }

    @media (max-width: 600px) {
      display: none;
    }
  }

  &__burger {
    display: none;
    flex-direction: column;
    gap: 5px;
    padding: 8px;
    background: $glass;
    border: none;
    border-radius: 8px;
    cursor: pointer;

    span {
      display: block;
      width: 24px;
      height: 2px;
      background: #fff;
      border-radius: 2px;
      transition: transform 0.3s, opacity 0.3s;
    }

    @media (max-width: 768px) {
      display: flex;
    }
  }

  &__mobile {
    display: flex;
    flex-direction: column;
    background: rgba(3, 44, 92, 0.98);
    backdrop-filter: blur(10px);
    padding: 16px 24px 24px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);

    @media (min-width: 769px) {
      display: none;
    }

    &-link {
      padding: 14px 0;
      color: #fff;
      font-family: 'Rubik', sans-serif;
      font-size: 18px;
      letter-spacing: -0.5px;
      text-decoration: none;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      text-transform: uppercase;

      &:last-child {
        border-bottom: none;
      }

      &:hover {
        color: $orange;
      }
    }
  }
}
</style>
