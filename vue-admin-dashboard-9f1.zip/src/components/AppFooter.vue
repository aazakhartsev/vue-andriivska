<template>
  <footer class="footer">
    <div class="footer__wave">
      <svg viewBox="0 0 1920 248" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
        <path d="M0 22.8558C756.414 81.606 1401.84 -50.5608 1952.78 22.8558C2503.72 96.2723 1971.28 161.003 1952.78 217.433C1934.29 273.863 0 234.881 0 234.881C0 234.881 -756.419 -35.8945 0 22.8558Z" fill="#002C5C"/>
        <rect x="0" y="210" width="1920" height="50" fill="#02438A"/>
      </svg>
    </div>
    <div class="footer__body">
      <div class="footer__inner">
        <router-link to="/">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/64a48292dd05693323002855f49c3eec35e918a3?width=268"
            alt="Андріївська"
            class="footer__logo"
          />
        </router-link>

        <nav class="footer__nav">
          <router-link to="/pro-nas" class="footer__link">Про нас</router-link>
          <router-link to="/tsiny" class="footer__link">Ціни</router-link>
          <router-link to="/partnerams" class="footer__link">Партнерам</router-link>
        </nav>

        <div class="footer__contacts">
          <a href="tel:+380634908000" class="footer__phone">+38 (063) 490 8000</a>
          <div class="footer__socials">
            <a href="#" class="footer__social" aria-label="Instagram">
              <svg width="18" height="18" viewBox="0 0 47 47" fill="none">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M35.1347 18.304C31.0576 17.8518 26.9431 17.8518 22.866 18.304C20.5187 18.5665 18.6228 20.4156 18.3475 22.7746C17.8646 26.91 17.8646 31.0876 18.3475 35.223C18.6228 37.582 20.5175 39.4311 22.866 39.6936C26.9431 40.1449 31.0576 40.1449 35.1347 39.6936C37.482 39.4311 39.3778 37.582 39.6532 35.223C40.1361 31.0876 40.1361 26.91 39.6532 22.7746C39.3778 20.4156 37.4832 18.5665 35.1347 18.304ZM28.9997 23.457C27.5299 23.457 26.1204 24.0409 25.0811 25.0801C24.0419 26.1194 23.458 27.529 23.458 28.9987C23.458 30.4684 24.0419 31.878 25.0811 32.9172C26.1204 33.9565 27.5299 34.5404 28.9997 34.5404C30.4694 34.5404 31.879 33.9565 32.9182 32.9172C33.9575 31.878 34.5413 30.4684 34.5413 28.9987C34.5413 27.529 33.9575 26.1194 32.9182 25.0801C31.879 24.0409 30.4694 23.457 28.9997 23.457Z" fill="white"/>
                <path d="M33.667 23.1667C33.667 22.8572 33.7899 22.5605 34.0087 22.3417C34.2275 22.1229 34.5242 22 34.8337 22C35.1431 22 35.4398 22.1229 35.6586 22.3417C35.8774 22.5605 36.0003 22.8572 36.0003 23.1667C36.0003 23.4761 35.8774 23.7728 35.6586 23.9916C35.4398 24.2104 35.1431 24.3333 34.8337 24.3333C34.5242 24.3333 34.2275 24.2104 34.0087 23.9916C33.7899 23.7728 33.667 23.4761 33.667 23.1667Z" fill="white"/>
              </svg>
            </a>
            <a href="#" class="footer__social" aria-label="Facebook">
              <svg width="18" height="18" viewBox="0 0 35 35" fill="none">
                <path d="M19 10H15.7273C14.2806 10 12.8933 10.5795 11.8703 11.611C10.8474 12.6424 10.2727 14.0414 10.2727 15.5V18.8H7V23.2H10.2727V32H14.6364V23.2H17.9091L19 18.8H14.6364V15.5C14.6364 15.2083 14.7513 14.9285 14.9559 14.7222C15.1605 14.5159 15.4379 14.4 15.7273 14.4H19V10Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </a>
            <a href="#" class="footer__social" aria-label="LinkedIn">
              <svg width="18" height="18" viewBox="0 0 42 42" fill="none">
                <path d="M1.6875 5.9375C1.6875 6.534 1.9246 7.107 2.3465 7.529C2.7685 7.951 3.3408 8.188 3.9375 8.188C4.5342 8.188 5.1065 7.951 5.5285 7.529C5.9504 7.107 6.1875 6.534 6.1875 5.9375C6.1875 5.341 5.9504 4.769 5.5285 4.347C5.1065 3.925 4.5342 3.688 3.9375 3.688C3.3408 3.688 2.7685 3.925 2.3465 4.347C1.9246 4.769 1.6875 5.341 1.6875 5.9375ZM1.6875 27.3125V11.5625H6.1875V27.3125H1.6875ZM9 11.5625V27.3125H13.5V19.541C13.5 18.313 14.625 16.063 17.8819 16.063C19.7303 16.063 20.8125 17.013 20.8125 18.875V27.3125H25.3125V18.875C25.3125 17.402 24.9615 15.571 23.7443 14.063C22.4573 12.469 20.4671 11.563 17.883 11.563C16.1809 11.563 14.6936 12.254 13.5 13.099V11.5625H9Z" stroke="white" stroke-width="1.375" stroke-linejoin="round"/>
              </svg>
            </a>
          </div>
        </div>
      </div>
      <p class="footer__copy">Андріївська © 2026. Всі права захищені.</p>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'AppFooter',
}
</script>

<style lang="scss" scoped>
$orange: #FF7A2A;

.footer {
  position: relative;
  overflow: hidden;

  &__wave {
    width: 100%;
    height: clamp(100px, 13vw, 200px);
    overflow: hidden;

    svg {
      width: 100%;
      height: 100%;
      display: block;
    }
  }

  &__body {
    background: #02438A;
    padding: clamp(16px, 2.5vw, 36px) clamp(20px, 5vw, 80px) clamp(16px, 2vw, 28px);
  }

  &__inner {
    max-width: 1600px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    gap: clamp(16px, 3vw, 40px);
    flex-wrap: wrap;
    margin-bottom: clamp(12px, 2vw, 20px);

    @media (max-width: 768px) {
      flex-direction: column;
      align-items: center;
      text-align: center;
    }
  }

  &__logo {
    width: clamp(80px, 8vw, 134px);
    height: auto;
    display: block;
  }

  &__nav {
    display: flex;
    gap: clamp(20px, 4vw, 80px);
    margin: 0 auto;

    @media (max-width: 768px) {
      margin: 0;
      gap: 20px;
    }
  }

  &__link {
    font-size: clamp(14px, 1.5vw, 20px);
    color: #fff;
    text-decoration: none;
    letter-spacing: -1px;
    line-height: 0.9;
    transition: color 0.2s;

    &:hover {
      color: $orange;
    }
  }

  &__contacts {
    display: flex;
    flex-direction: column;
    gap: clamp(8px, 1.2vw, 14px);
    align-items: flex-end;

    @media (max-width: 768px) {
      align-items: center;
    }
  }

  &__phone {
    display: inline-flex;
    align-items: center;
    padding: 8px 16px;
    border-radius: 30px;
    background: rgba(255, 255, 255, 0.10);
    color: #fff;
    font-size: clamp(14px, 1.4vw, 18px);
    letter-spacing: -0.9px;
    text-decoration: none;
    transition: background 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.18);
    }
  }

  &__socials {
    display: flex;
    gap: 10px;
  }

  &__social {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.10);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.20);
    }
  }

  &__copy {
    font-size: clamp(12px, 1.2vw, 16px);
    color: #fff;
    letter-spacing: -0.8px;
    line-height: 0.9;
    text-align: center;
    max-width: 1600px;
    margin: 0 auto;
    opacity: 0.7;
  }
}
</style>
