import { createRouter, createWebHistory } from 'vue-router'
import DefaultLayout from '../layouts/DefaultLayout.vue'
import HomeView from '../views/HomeView.vue'
import PlaceholderView from '../views/PlaceholderView.vue'

const routes = [
  {
    path: '/',
    component: DefaultLayout,
    children: [
      {
        path: '',
        name: 'home',
        component: HomeView,
      },
      {
        path: 'pro-nas',
        name: 'about',
        component: PlaceholderView,
        meta: { title: 'Про нас' },
      },
      {
        path: 'tsiny',
        name: 'prices',
        component: PlaceholderView,
        meta: { title: 'Ціни' },
      },
      {
        path: 'partnerams',
        name: 'partners',
        component: PlaceholderView,
        meta: { title: 'Партнерам' },
      },
    ],
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) return savedPosition
    return { top: 0 }
  },
})

export default router
