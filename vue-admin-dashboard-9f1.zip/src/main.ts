import './assets/main.css'
import 'vuetify/styles'

import { createApp } from 'vue'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

import router from './router/index.js'
import store from './store/index.js'
import App from './App.vue'

const vuetify = createVuetify({
  components,
  directives,
  theme: {
    defaultTheme: 'andriivska',
    themes: {
      andriivska: {
        dark: false,
        colors: {
          primary: '#FF7A2A',
          secondary: '#086AD4',
          background: '#033873',
        },
      },
    },
  },
})

createApp(App)
  .use(router)
  .use(store)
  .use(vuetify)
  .mount('#app')
