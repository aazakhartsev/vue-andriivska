<template>
  <v-app>
    <router-view />
  </v-app>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>
html, body, #app,
.v-application,
.v-application__wrap {
  background: transparent !important;
  background-color: transparent !important;
  min-height: 100vh;
}

html, body {
  background: linear-gradient(162deg, #033873 0.55%, #086AD4 99.39%) !important;
  background-attachment: fixed !important;
}
</style>
