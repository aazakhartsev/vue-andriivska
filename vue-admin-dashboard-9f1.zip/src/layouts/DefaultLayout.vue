<template>
  <div class="default-layout">
    <app-navbar />
    <main class="main-content">
      <router-view />
    </main>
    <app-footer />
  </div>
</template>

<script>
import AppNavbar from '../components/AppNavbar.vue'
import AppFooter from '../components/AppFooter.vue'

export default {
  name: 'DefaultLayout',
  components: {
    AppNavbar,
    AppFooter,
  },
}
</script>

<style lang="scss" scoped>
.default-layout {
  min-height: 100vh;
  background: linear-gradient(162deg, #033873 0.55%, #086AD4 99.39%);
  display: flex;
  flex-direction: column;
}

.main-content {
  flex: 1;
  position: relative;
}
</style>
